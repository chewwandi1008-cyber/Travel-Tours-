export interface TourPackage {
  id: string;
  title: string;
  category: string;
  duration: string;
  imageUrl: string;
  imageAlt: string;
  description: string;
  tags: string[];
  pricingNote: string;
  itineraryDays?: {
    day: string;
    title: string;
    highlights: string[];
  }[];
  included?: string[];
}

export interface BikeModel {
  id: string;
  name: string;
  type: string;
  ratePerDay: number;
  imageUrl: string;
  imageAlt: string;
  badge: string;
  badgeType?: 'available' | 'limited' | 'signature';
  engine: string;
  deposit: string;
  transmission: string;
  fuelCapacity: string;
  idealFor: string;
}

export interface Destination {
  id: string;
  name: string;
  category: string;
  imageUrl: string;
  imageAlt: string;
  description: string;
  highlights: string[];
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'beaches' | 'mountains' | 'heritage' | 'wildlife' | 'bikes';
  imageUrl: string;
  imageAlt: string;
}

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  country: string;
  flag: string;
  tourType: string;
  rating: number;
}
