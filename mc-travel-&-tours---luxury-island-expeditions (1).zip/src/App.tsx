/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { TourPackages } from './components/TourPackages';
import { TourDetailModal } from './components/TourDetailModal';
import { BikeRental } from './components/BikeRental';
import { BikeDetailModal } from './components/BikeDetailModal';
import { Destinations } from './components/Destinations';
import { WhyUs } from './components/WhyUs';
import { Gallery } from './components/Gallery';
import { Reviews } from './components/Reviews';
import { BookingSection } from './components/BookingSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';
import { TermsModal } from './components/TermsModal';
import { TourPackage, BikeModel } from './types';

export default function App() {
  const [currency, setCurrency] = useState<string>('USD');
  const [bookingCategory, setBookingCategory] = useState<string>('Sri Lanka Tour Package');
  const [bookingSelection, setBookingSelection] = useState<string>('');
  const [selectedTour, setSelectedTour] = useState<TourPackage | null>(null);
  const [selectedBike, setSelectedBike] = useState<BikeModel | null>(null);
  const [legalModal, setLegalModal] = useState<'terms' | 'privacy' | 'safety' | null>(null);

  // Currency converter
  const formatPrice = (usd: number): string => {
    switch (currency) {
      case 'EUR':
        return `€${Math.round(usd * 0.92)}`;
      case 'GBP':
        return `£${Math.round(usd * 0.79)}`;
      case 'LKR':
        return `Rs ${Math.round(usd * 310).toLocaleString()}`;
      case 'USD':
      default:
        return `$${usd} USD`;
    }
  };

  const scrollToHash = (hash: string) => {
    const el = document.querySelector(hash);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenBooking = () => {
    scrollToHash('#booking');
  };

  const handleSelectServiceCategory = (category: string) => {
    setBookingCategory(category);
    scrollToHash('#booking');
  };

  const handleRequestTourQuote = (packageName: string) => {
    setBookingCategory('Sri Lanka Tour Package');
    setBookingSelection(packageName);
    scrollToHash('#booking');
  };

  const handlePlanDestination = (destName: string) => {
    setBookingCategory('Customized Private Tour');
    setBookingSelection(`Destination: ${destName}`);
    scrollToHash('#booking');
  };

  const handleSelectBikeFromModal = (bikeName: string, rate: number) => {
    setBookingCategory('Bike & Scooter Rental');
    setBookingSelection(`${bikeName} (${formatPrice(rate)}/day)`);
    scrollToHash('#bikerental');
  };

  return (
    <div className="min-h-screen bg-[#f9f9f9] text-[#1a1c1c] flex flex-col font-['Plus_Jakarta_Sans'] selection:bg-[#6cf8bb] selection:text-[#002113]">
      {/* Sticky Header */}
      <Header
        onOpenBooking={handleOpenBooking}
        currency={currency}
        setCurrency={setCurrency}
      />

      {/* Main Content Sections */}
      <main className="w-full flex-1">
        {/* SECTION 1: HERO */}
        <Hero
          onExploreTours={() => scrollToHash('#packages')}
          onRentBike={() => scrollToHash('#bikerental')}
        />

        {/* SECTION 2: ABOUT US */}
        <About />

        {/* SECTION 3: SERVICES */}
        <Services
          onSelectCategory={handleSelectServiceCategory}
          onNavigate={scrollToHash}
        />

        {/* SECTION 4: TOUR PACKAGES */}
        <TourPackages
          onRequestQuote={handleRequestTourQuote}
          onOpenDetail={(pkg) => setSelectedTour(pkg)}
        />

        {/* SECTION 5: BIKE & SCOOTER RENTAL FLEET */}
        <BikeRental
          onOpenBikeModal={(bike) => setSelectedBike(bike)}
          currency={currency}
          formatPrice={formatPrice}
        />

        {/* SECTION 6: DESTINATIONS */}
        <Destinations onPlanDestination={handlePlanDestination} />

        {/* SECTION 7: WHY CHOOSE US */}
        <WhyUs />

        {/* SECTION 8: EXPEDITION GALLERY */}
        <Gallery />

        {/* SECTION 9: BOOKING & INQUIRY FORM */}
        <BookingSection
          initialCategory={bookingCategory}
          initialSelection={bookingSelection}
        />

        {/* SECTION 10: TESTIMONIALS */}
        <Reviews />

        {/* SECTION 11: CONTACT CONCIERGE & STATIONS */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer
        onOpenLegal={(type) => setLegalModal(type)}
        onNavigate={scrollToHash}
      />

      {/* Floating Action Buttons */}
      <FloatingActions />

      {/* Tour Detail Modal */}
      <TourDetailModal
        pkg={selectedTour}
        onClose={() => setSelectedTour(null)}
        onRequestQuote={handleRequestTourQuote}
      />

      {/* Bike Technical Detail Modal */}
      <BikeDetailModal
        bike={selectedBike}
        onClose={() => setSelectedBike(null)}
        onSelectBike={handleSelectBikeFromModal}
        currency={currency}
        formatPrice={formatPrice}
      />

      {/* Legal & Safety Charter Modal */}
      <TermsModal
        type={legalModal}
        onClose={() => setLegalModal(null)}
      />
    </div>
  );
}
