import React, { useState } from 'react';
import { TOUR_PACKAGES } from '../data/mockData';
import { TourPackage } from '../types';

interface TourPackagesProps {
  onRequestQuote: (packageName: string) => void;
  onOpenDetail: (pkg: TourPackage) => void;
}

export const TourPackages: React.FC<TourPackagesProps> = ({
  onRequestQuote,
  onOpenDetail
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'Southern Coast',
    'Hill Country',
    'Sacred Heritage',
    'Ancient Triangle',
    'Wildlife Safari',
    'Ultimate Experience'
  ];

  const filteredPackages = selectedCategory === 'All'
    ? TOUR_PACKAGES
    : TOUR_PACKAGES.filter((p) => p.category.toLowerCase().includes(selectedCategory.toLowerCase()) || p.tags.some(t => t.toLowerCase().includes(selectedCategory.toLowerCase())));

  return (
    <section className="w-full py-20 bg-[#f9f9f9]" id="packages">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col gap-10">
        {/* Section Title & Filter Info */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="w-8 h-0.5 bg-[#006c49]" />
              <span className="text-xs uppercase tracking-widest text-[#006c49] font-bold">
                Curated Itineraries
              </span>
            </div>
            <h2 className="font-['Outfit'] text-3xl md:text-4xl text-[#000917] font-bold tracking-tight">
              Sample Tour Packages
            </h2>
            <p className="text-sm md:text-base text-[#44474d]">
              Explore sample route packages designed by our destination specialists. All packages can be customized for your travel dates, group size, and preferred accommodation class.
            </p>
          </div>

          <div className="p-2.5 px-4 rounded-xl bg-[#e8e8e8] text-[#44474d] text-xs font-semibold flex items-center gap-2 self-start md:self-auto">
            <span className="material-symbols-outlined text-[18px] text-[#006c49]">info</span>
            <span>Contact for custom price quote</span>
          </div>
        </div>

        {/* Category Filter Chips */}
        <div className="flex flex-wrap items-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#000917] text-white shadow-sm'
                  : 'bg-[#eeeeee] text-[#44474d] hover:bg-[#e2e2e2]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredPackages.map((pkg) => (
            <div
              key={pkg.id}
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col border border-[#eeeeee]"
            >
              <div className="relative h-48 w-full bg-[#e8e8e8] overflow-hidden group">
                <img
                  src={pkg.imageUrl}
                  alt={pkg.imageAlt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-[#000917]/75 backdrop-blur-md text-white text-xs font-semibold">
                  {pkg.duration}
                </span>

                <button
                  onClick={() => onOpenDetail(pkg)}
                  className="absolute bottom-3 right-3 px-2.5 py-1 rounded-lg bg-white/90 backdrop-blur-md text-[#000917] text-[11px] font-semibold hover:bg-white shadow-md flex items-center gap-1 transition-colors cursor-pointer"
                  title="View complete itinerary details"
                >
                  <span className="material-symbols-outlined text-[14px]">visibility</span>
                  <span>View Details</span>
                </button>
              </div>

              <div className="p-5 flex flex-col flex-1 justify-between gap-4">
                <div className="flex flex-col gap-2">
                  <span className="text-[11px] uppercase tracking-wider text-[#006c49] font-bold">
                    {pkg.category}
                  </span>
                  <h3 className="font-['Outfit'] font-semibold text-base sm:text-lg text-[#000917] leading-snug">
                    {pkg.title}
                  </h3>
                  <p className="text-xs text-[#44474d] line-clamp-3 leading-relaxed">
                    {pkg.description}
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {pkg.tags.map((tag, tIdx) => (
                      <span
                        key={tIdx}
                        className="px-2 py-0.5 rounded bg-[#eeeeee] text-[11px] text-[#44474d]"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-[#eeeeee] flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#44474d]">Pricing:</span>
                    <span className="text-xs font-bold text-[#000917]">Custom Quote</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onOpenDetail(pkg)}
                      className="py-2.5 px-2 rounded-lg bg-[#eeeeee] text-[#000917] text-xs font-semibold hover:bg-[#e2e2e2] transition-colors text-center cursor-pointer"
                    >
                      Itinerary
                    </button>
                    <button
                      onClick={() => onRequestQuote(`${pkg.title} (${pkg.duration})`)}
                      className="py-2.5 px-2 rounded-lg bg-[#000917] text-white text-xs font-semibold hover:bg-[#006c49] transition-colors text-center cursor-pointer"
                    >
                      Request Quote
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
