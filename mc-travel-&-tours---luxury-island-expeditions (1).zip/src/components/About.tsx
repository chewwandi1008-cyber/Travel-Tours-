import React from 'react';

export const About: React.FC = () => {
  return (
    <section className="w-full py-20 bg-[#f9f9f9]" id="about">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Left: Image Composition with Depth */}
          <div className="lg:col-span-6 relative">
            <div className="relative w-full h-[380px] sm:h-[460px] rounded-2xl overflow-hidden shadow-xl bg-[#e8e8e8]">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuChs-en4mcnqcFSFtfOCEp7tRjWQ9kwIUKBZKbItoUTZGuL9i3vwEH_Qi0SGQ9bFuQKvVo2hNuySBnoc3l1wdP_LXdqKVcX-FTUaKRlicZk1WOkFJahIJGxxFSRljL8kXFkggYhf5SIKyMzpQXLMCEwZ-Kzd9QDZ4M4euFnFnE38puuD5FasWRNLcsSS3JiE9p6QGlZzv3gkklXHbOUZzURMWthPVpeRzfvyCSjTCoU8KznNV3MlpKx"
                alt="A friendly local Sri Lankan driver guide chatting with happy international travellers beside a modern air-conditioned van against the backdrop of rolling green tea fields in Nuwara Eliya"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Overlapping Card */}
            <div className="absolute -bottom-6 -right-2 sm:right-6 bg-white p-5 rounded-2xl shadow-xl max-w-xs border border-[#eeeeee] flex flex-col gap-1.5">
              <div className="flex items-center gap-2 text-[#006c49] font-bold text-base">
                <span className="material-symbols-outlined text-[24px]">verified</span>
                <span>Local Island Hosts</span>
              </div>
              <p className="text-xs text-[#44474d] leading-relaxed">
                Galle &amp; Colombo based logistics network dedicated to genuine care and hassle-free transit.
              </p>
            </div>
          </div>

          {/* Right: Story & 6 Pillars */}
          <div className="lg:col-span-6 flex flex-col gap-4 mt-6 lg:mt-0">
            <div className="flex items-center gap-2">
              <span className="w-8 h-0.5 bg-[#006c49]" />
              <span className="text-xs uppercase tracking-widest text-[#006c49] font-bold">
                Welcome to MC Travel
              </span>
            </div>

            <h2 className="font-['Outfit'] text-2xl sm:text-3xl lg:text-4xl text-[#000917] font-bold tracking-tight">
              Dedicated Island Hospitality &amp; Authentic Island Travel
            </h2>

            <p className="text-sm sm:text-base text-[#44474d] leading-relaxed">
              Founded with a passion for genuine Sri Lankan hospitality, MC Travel &amp; Tours connects independent travellers, couples, and families with the island’s authentic beauty. Whether you are catching the sunrise surf at Weligama, wandering through the Dutch ramparts of Galle Fort, or seeking the serenity of central highland tea estates, our dedicated team is here to ensure seamless, safe, and memorable journeys.
            </p>

            {/* 6 Pillars Bento Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="p-3.5 rounded-xl bg-white shadow-sm border border-[#eeeeee] flex flex-col gap-1 hover:border-[#6cf8bb] transition-colors">
                <div className="flex items-center gap-2 text-[#000917] font-semibold text-sm">
                  <span className="material-symbols-outlined text-[20px] text-[#006c49]">sentiment_satisfied</span>
                  <span>Friendly Customer Service</span>
                </div>
                <p className="text-xs text-[#44474d]">Attentive local team ready with recommendations and real-time guidance.</p>
              </div>

              <div className="p-3.5 rounded-xl bg-white shadow-sm border border-[#eeeeee] flex flex-col gap-1 hover:border-[#6cf8bb] transition-colors">
                <div className="flex items-center gap-2 text-[#000917] font-semibold text-sm">
                  <span className="material-symbols-outlined text-[20px] text-[#006c49]">alt_route</span>
                  <span>Flexible Arrangements</span>
                </div>
                <p className="text-xs text-[#44474d]">Adapt tour pacing or pickup timings to your personal vacation rhythms.</p>
              </div>

              <div className="p-3.5 rounded-xl bg-white shadow-sm border border-[#eeeeee] flex flex-col gap-1 hover:border-[#6cf8bb] transition-colors">
                <div className="flex items-center gap-2 text-[#000917] font-semibold text-sm">
                  <span className="material-symbols-outlined text-[20px] text-[#006c49]">person_pin_circle</span>
                  <span>Personalized Tours</span>
                </div>
                <p className="text-xs text-[#44474d]">From slow coastal retreats to high-adrenaline mountain ridge circuits.</p>
              </div>

              <div className="p-3.5 rounded-xl bg-white shadow-sm border border-[#eeeeee] flex flex-col gap-1 hover:border-[#6cf8bb] transition-colors">
                <div className="flex items-center gap-2 text-[#000917] font-semibold text-sm">
                  <span className="material-symbols-outlined text-[20px] text-[#006c49]">directions_car</span>
                  <span>Comfortable Transport</span>
                </div>
                <p className="text-xs text-[#44474d]">Clean, modern air-conditioned sedans, spacious passenger vans, and SUVs.</p>
              </div>

              <div className="p-3.5 rounded-xl bg-white shadow-sm border border-[#eeeeee] flex flex-col gap-1 hover:border-[#6cf8bb] transition-colors">
                <div className="flex items-center gap-2 text-[#000917] font-semibold text-sm">
                  <span className="material-symbols-outlined text-[20px] text-[#006c49]">two_wheeler</span>
                  <span>Curated Bike Rentals</span>
                </div>
                <p className="text-xs text-[#44474d]">Automatic scooters and road-ready adventure bikes with safety helmets.</p>
              </div>

              <div className="p-3.5 rounded-xl bg-white shadow-sm border border-[#eeeeee] flex flex-col gap-1 hover:border-[#6cf8bb] transition-colors">
                <div className="flex items-center gap-2 text-[#000917] font-semibold text-sm">
                  <span className="material-symbols-outlined text-[20px] text-[#006c49]">pin_drop</span>
                  <span>Local Knowledge</span>
                </div>
                <p className="text-xs text-[#44474d]">Insider tips on local eateries, secluded surf spots, and scenic detours.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
