import React, { useState, useEffect } from 'react';

export const FloatingActions: React.FC = () => {
  const [showBackToTop, setShowBackToTop] = useState<boolean>(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-center gap-3">
      {/* Floating WhatsApp */}
      <a
        href="https://wa.me/94771234567?text=Hello%20MC%20Travel%20%26%20Tours,%20I%20would%20like%20to%20inquire%20about%20your%20island%20tours%20and%20bike%20rentals."
        target="_blank"
        rel="noopener noreferrer"
        title="Chat with Concierge on WhatsApp"
        className="w-13 h-13 p-3 rounded-full bg-[#006c49] text-white shadow-[0_12px_32px_-4px_rgba(10,25,47,0.25)] hover:bg-[#6ffbbe] hover:text-[#002113] hover:scale-105 transition-all flex items-center justify-center group"
      >
        <span className="material-symbols-outlined text-[26px]">chat</span>
      </a>

      {/* Back to Top */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          title="Back to top"
          className="w-11 h-11 rounded-full bg-white text-[#000917] shadow-[0_4px_20px_-2px_rgba(10,25,47,0.15)] hover:bg-[#000917] hover:text-white hover:-translate-y-1 transition-all flex items-center justify-center border border-[#eeeeee] cursor-pointer animate-fadeIn"
        >
          <span className="material-symbols-outlined text-[20px]">arrow_upward</span>
        </button>
      )}
    </div>
  );
};
