import React, { useState, useEffect } from 'react';
import { GALLERY_ITEMS } from '../data/mockData';
import { GalleryItem } from '../types';

export const Gallery: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filterTabs = [
    { id: 'all', label: 'All' },
    { id: 'beaches', label: 'Beaches' },
    { id: 'mountains', label: 'Mountain Roads' },
    { id: 'heritage', label: 'Heritage' },
    { id: 'wildlife', label: 'Wildlife' },
    { id: 'bikes', label: 'Scooters & Bikes' }
  ];

  const filteredItems = activeCategory === 'all'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter((item) => item.category === activeCategory);

  // Keyboard navigation for Lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') {
        setLightboxIndex(null);
      } else if (e.key === 'ArrowRight') {
        setLightboxIndex((prev) => (prev !== null ? (prev + 1) % GALLERY_ITEMS.length : 0));
      } else if (e.key === 'ArrowLeft') {
        setLightboxIndex((prev) => (prev !== null ? (prev - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length : 0));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex]);

  const activePhoto = lightboxIndex !== null ? GALLERY_ITEMS[lightboxIndex] : null;

  return (
    <section className="w-full py-20 bg-[#f9f9f9]" id="gallery">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col gap-10">
        {/* Section Header & Filter Tabs */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="w-8 h-0.5 bg-[#006c49]" />
              <span className="text-xs uppercase tracking-widest text-[#006c49] font-bold">
                Visual Travelogues
              </span>
            </div>
            <h2 className="font-['Outfit'] text-3xl md:text-4xl text-[#000917] font-bold tracking-tight">
              Expedition Moments
            </h2>
            <p className="text-sm md:text-base text-[#44474d]">
              Snapshots from recent coastal rides, misty tea hills, and wildlife safaris across Sri Lanka.
            </p>
          </div>

          {/* Filter Chips */}
          <div className="flex flex-wrap gap-2">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-colors cursor-pointer ${
                  activeCategory === tab.id
                    ? 'bg-[#000917] text-white'
                    : 'bg-[#eeeeee] hover:bg-[#e2e2e2] text-[#1a1c1c]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Masonry / Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredItems.map((item) => {
            const originalIdx = GALLERY_ITEMS.findIndex((g) => g.id === item.id);
            return (
              <div
                key={item.id}
                onClick={() => setLightboxIndex(originalIdx)}
                className="group relative h-72 rounded-2xl overflow-hidden cursor-pointer bg-[#e8e8e8] border border-[#eeeeee]"
              >
                <img
                  src={item.imageUrl}
                  alt={item.imageAlt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#000917]/85 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                  <span className="text-[10px] text-[#6ffbbe] uppercase tracking-wider font-bold">
                    {item.category}
                  </span>
                  <span className="font-['Outfit'] font-bold text-sm sm:text-base text-white">
                    {item.title}
                  </span>
                  <span className="text-[11px] text-[#b5c8e5] mt-1 flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">fullscreen</span>
                    <span>Click to enlarge</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* LIGHTBOX MODAL OVERLAY */}
      {lightboxIndex !== null && activePhoto && (
        <div className="fixed inset-0 z-50 bg-[#000917]/95 backdrop-blur-xl flex flex-col items-center justify-between p-4 md:p-8 animate-fadeIn">
          {/* Top Bar with Counter and Close */}
          <div className="w-full max-w-5xl flex items-center justify-between text-white">
            <span className="text-xs font-semibold text-[#b5c8e5]">
              {lightboxIndex + 1} / {GALLERY_ITEMS.length}
            </span>
            <button
              onClick={() => setLightboxIndex(null)}
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors text-white cursor-pointer"
              aria-label="Close Lightbox"
            >
              <span className="material-symbols-outlined text-[24px]">close</span>
            </button>
          </div>

          {/* Central Image & Navigation */}
          <div className="relative w-full max-w-4xl flex items-center justify-center my-auto">
            {/* Prev button */}
            <button
              onClick={() =>
                setLightboxIndex((prev) => (prev !== null ? (prev - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length : 0))
              }
              className="absolute -left-2 md:-left-14 z-10 w-11 h-11 rounded-full bg-white/10 hover:bg-[#006c49] flex items-center justify-center text-white transition-colors cursor-pointer"
              aria-label="Previous image"
            >
              <span className="material-symbols-outlined text-[26px]">chevron_left</span>
            </button>

            {/* Displayed Image */}
            <div className="w-full max-h-[75vh] flex flex-col items-center">
              <img
                src={activePhoto.imageUrl}
                alt={activePhoto.imageAlt}
                className="max-h-[65vh] w-auto max-w-full rounded-xl object-contain shadow-2xl"
                referrerPolicy="no-referrer"
              />
              <p className="mt-4 font-['Outfit'] font-bold text-lg text-white text-center">
                {activePhoto.title}
              </p>
            </div>

            {/* Next button */}
            <button
              onClick={() =>
                setLightboxIndex((prev) => (prev !== null ? (prev + 1) % GALLERY_ITEMS.length : 0))
              }
              className="absolute -right-2 md:-right-14 z-10 w-11 h-11 rounded-full bg-white/10 hover:bg-[#006c49] flex items-center justify-center text-white transition-colors cursor-pointer"
              aria-label="Next image"
            >
              <span className="material-symbols-outlined text-[26px]">chevron_right</span>
            </button>
          </div>

          {/* Bottom Help note */}
          <div className="text-[#b5c8e5] text-xs pb-2">
            Press <kbd className="px-2 py-0.5 rounded bg-white/10 text-white font-mono">Esc</kbd> to close, or use <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">←</kbd> <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">→</kbd> Arrow keys to browse.
          </div>
        </div>
      )}
    </section>
  );
};
