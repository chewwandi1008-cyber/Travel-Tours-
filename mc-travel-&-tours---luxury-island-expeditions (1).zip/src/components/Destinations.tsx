import React from 'react';
import { DESTINATIONS } from '../data/mockData';

interface DestinationsProps {
  onPlanDestination: (destName: string) => void;
}

export const Destinations: React.FC<DestinationsProps> = ({ onPlanDestination }) => {
  return (
    <section className="w-full py-20 bg-[#f9f9f9]" id="destinations">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col gap-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="w-8 h-0.5 bg-[#006c49]" />
              <span className="text-xs uppercase tracking-widest text-[#006c49] font-bold">
                Island Highlights
              </span>
            </div>
            <h2 className="font-['Outfit'] text-3xl md:text-4xl text-[#000917] font-bold tracking-tight">
              Popular Island Destinations
            </h2>
            <p className="text-sm md:text-base text-[#44474d]">
              From UNESCO colonial forts and warm surf breaks to highland mountain trails and wild savannahs.
            </p>
          </div>
        </div>

        {/* 9 Destinations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {DESTINATIONS.map((dest) => (
            <div
              key={dest.id}
              className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col border border-[#eeeeee]"
            >
              <div className="relative h-56 w-full overflow-hidden bg-[#e8e8e8]">
                <img
                  src={dest.imageUrl}
                  alt={dest.imageAlt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-[#000917]/80 backdrop-blur-md text-white text-xs font-semibold">
                  {dest.category}
                </span>
              </div>

              <div className="p-6 flex flex-col justify-between flex-1 gap-4">
                <div className="flex flex-col gap-1.5">
                  <h3 className="font-['Outfit'] text-xl font-bold text-[#000917]">
                    {dest.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#44474d] leading-relaxed">
                    {dest.description}
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {dest.highlights.map((h, hIdx) => (
                      <span
                        key={hIdx}
                        className="px-2 py-0.5 rounded bg-[#f3f3f4] text-[11px] text-[#44474d]"
                      >
                        {h}
                      </span>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => onPlanDestination(dest.name)}
                  className="w-full py-2.5 rounded-lg bg-[#eeeeee] hover:bg-[#006c49] hover:text-white text-[#000917] text-xs font-semibold transition-colors cursor-pointer"
                >
                  Plan Trip Here
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
