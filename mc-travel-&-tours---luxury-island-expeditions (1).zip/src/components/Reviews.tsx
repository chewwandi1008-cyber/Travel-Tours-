import React, { useState } from 'react';
import { TESTIMONIALS } from '../data/mockData';

export const Reviews: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [reviewsList, setReviewsList] = useState(TESTIMONIALS);
  const [showAddReview, setShowAddReview] = useState<boolean>(false);
  const [newAuthor, setNewAuthor] = useState<string>('');
  const [newCountry, setNewCountry] = useState<string>('');
  const [newQuote, setNewQuote] = useState<string>('');
  const [newTourType, setNewTourType] = useState<string>('Custom Tour');
  const [newRating, setNewRating] = useState<number>(5);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + reviewsList.length) % reviewsList.length);
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % reviewsList.length);
  };

  const handleAddReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor || !newQuote) return;
    const newRev = {
      id: `custom-${Date.now()}`,
      quote: newQuote,
      author: newAuthor,
      country: newCountry || 'International Traveler',
      flag: '🌏',
      tourType: newTourType,
      rating: newRating
    };
    setReviewsList([newRev, ...reviewsList]);
    setCurrentIndex(0);
    setShowAddReview(false);
    setNewAuthor('');
    setNewQuote('');
    setNewCountry('');
  };

  return (
    <section className="w-full py-20 bg-[#f9f9f9]" id="reviews">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col gap-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="w-8 h-0.5 bg-[#006c49]" />
              <span className="text-xs uppercase tracking-widest text-[#006c49] font-bold">
                Traveller Stories
              </span>
            </div>
            <h2 className="font-['Outfit'] text-3xl md:text-4xl text-[#000917] font-bold tracking-tight">
              Guest Testimonials
            </h2>
            <p className="text-xs sm:text-sm text-[#44474d]">
              Real experiences from international visitors who toured Sri Lanka with our fleet and drivers.
            </p>
          </div>

          <div className="flex items-center gap-3 self-start md:self-auto">
            <button
              onClick={() => setShowAddReview(true)}
              className="px-3.5 py-2 rounded-xl bg-[#eeeeee] hover:bg-[#e2e2e2] text-xs font-semibold text-[#000917] transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">edit</span>
              <span>Leave a Review</span>
            </button>
            <div className="flex items-center gap-1.5">
              <button
                onClick={prevSlide}
                className="w-10 h-10 rounded-full bg-[#eeeeee] hover:bg-[#000917] hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                aria-label="Previous review"
              >
                <span className="material-symbols-outlined text-[20px]">arrow_back</span>
              </button>
              <button
                onClick={nextSlide}
                className="w-10 h-10 rounded-full bg-[#eeeeee] hover:bg-[#000917] hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                aria-label="Next review"
              >
                <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
              </button>
            </div>
          </div>
        </div>

        {/* Testimonials Grid / Carousel */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[0, 1, 2].map((offset) => {
            const idx = (currentIndex + offset) % reviewsList.length;
            const rev = reviewsList[idx];
            return (
              <div
                key={rev.id}
                className="bg-white rounded-2xl p-6 shadow-sm border border-[#eeeeee] flex flex-col justify-between hover:shadow-md transition-shadow"
              >
                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-1 text-[#ffb95f]">
                    {Array.from({ length: rev.rating }).map((_, rIdx) => (
                      <span
                        key={rIdx}
                        className="material-symbols-outlined text-[20px]"
                        style={{ fontVariationSettings: "'FILL' 1" }}
                      >
                        star
                      </span>
                    ))}
                  </div>

                  <p className="text-sm text-[#1a1c1c] italic leading-relaxed">
                    "{rev.quote}"
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#f3f3f4] flex items-center justify-between">
                  <div>
                    <span className="font-['Outfit'] font-bold text-sm text-[#000917] block">
                      {rev.author}
                    </span>
                    <p className="text-xs text-[#44474d] flex items-center gap-1 mt-0.5">
                      <span>{rev.country}</span>
                      <span>{rev.flag}</span>
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded bg-[#6ffbbe]/40 text-[10px] font-bold text-[#002113]">
                    {rev.tourType}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Carousel Dot Indicators */}
        <div className="flex items-center justify-center gap-2">
          {reviewsList.map((_, dotIdx) => (
            <button
              key={dotIdx}
              onClick={() => setCurrentIndex(dotIdx)}
              className={`transition-all rounded-full cursor-pointer ${
                currentIndex === dotIdx ? 'w-8 h-2 bg-[#006c49]' : 'w-2 h-2 bg-[#c4c6cd]'
              }`}
              aria-label={`Go to slide ${dotIdx + 1}`}
            />
          ))}
        </div>
      </div>

      {/* Add Review Modal */}
      {showAddReview && (
        <div className="fixed inset-0 z-50 bg-[#000917]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 md:p-8 max-w-lg w-full shadow-2xl flex flex-col gap-4 border border-[#eeeeee]">
            <div className="flex items-center justify-between">
              <h3 className="font-['Outfit'] text-xl font-bold text-[#000917]">
                Share Your Island Experience
              </h3>
              <button
                onClick={() => setShowAddReview(false)}
                className="w-8 h-8 rounded-full bg-[#eeeeee] flex items-center justify-center text-[#000917]"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <form onSubmit={handleAddReviewSubmit} className="flex flex-col gap-3">
              <div>
                <label className="text-xs font-semibold text-[#000917]">Your Name *</label>
                <input
                  type="text"
                  required
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  placeholder="e.g. Elena Rostova"
                  className="w-full px-3 py-2 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] text-sm mt-1"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-[#000917]">Country</label>
                  <input
                    type="text"
                    value={newCountry}
                    onChange={(e) => setNewCountry(e.target.value)}
                    placeholder="e.g. France"
                    className="w-full px-3 py-2 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] text-sm mt-1"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#000917]">Tour / Fleet Used</label>
                  <select
                    value={newTourType}
                    onChange={(e) => setNewTourType(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] text-sm mt-1"
                  >
                    <option value="Scooter Rental">Scooter Rental</option>
                    <option value="Royal Enfield">Royal Enfield</option>
                    <option value="Private Van Tour">Private Van Tour</option>
                    <option value="Airport Transfer">Airport Transfer</option>
                    <option value="Wildlife Safari">Wildlife Safari</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#000917]">Rating</label>
                <div className="flex items-center gap-2 mt-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setNewRating(star)}
                      className={`text-2xl cursor-pointer ${star <= newRating ? 'text-[#ffb95f]' : 'text-gray-300'}`}
                    >
                      ★
                    </button>
                  ))}
                  <span className="text-xs text-[#44474d] ml-2">{newRating} Stars</span>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#000917]">Your Feedback / Story *</label>
                <textarea
                  rows={3}
                  required
                  value={newQuote}
                  onChange={(e) => setNewQuote(e.target.value)}
                  placeholder="Tell future travellers about your experience..."
                  className="w-full px-3 py-2 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] text-sm mt-1"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddReview(false)}
                  className="px-4 py-2 rounded-lg bg-[#eeeeee] text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#006c49] text-white text-xs font-semibold hover:bg-[#000917]"
                >
                  Submit Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
