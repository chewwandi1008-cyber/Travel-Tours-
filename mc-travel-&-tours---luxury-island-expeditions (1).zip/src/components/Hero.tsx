import React from 'react';

interface HeroProps {
  onExploreTours: () => void;
  onRentBike: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreTours, onRentBike }) => {
  return (
    <section className="relative w-full overflow-hidden bg-[#000917] text-white pt-28 pb-20 md:pt-36 md:pb-28" id="home">
      {/* Atmospheric Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center mix-blend-overlay opacity-40 scale-105 transition-transform duration-1000 ease-out"
        style={{
          backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXuC9320e7oVfi_qSAUfA7E5TcVnKERtit5Ex5d5xayZrov5jIpd3b5gyYjBqCroRZOBJzeZ7WQ_4PR_kmbhT6l1hijUEglwnZm_FQXroye1ZVP7d0YmN5TYHCM3jJeK9keyZRkRNtTQFR5Whjj__EASJ6ST1dpCZtXkUVmqL7BVeG0OpMKslp7YOnUE9uA8FGkv0JEMKsrPYDYWeqMjewgha52V-e0c3IlGf9mw_PMMAv6_DZ3t2z2w4')`
        }}
      />

      {/* Ambient Depth Gradients */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#000917]/80 via-[#000917]/60 to-[#000917]" />
      <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-[#006c49]/20 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 -left-20 w-80 h-80 rounded-full bg-[#ffddb8]/15 blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col justify-between min-h-[640px] md:min-h-[720px]">
        {/* Headline & Story */}
        <div className="max-w-3xl flex flex-col gap-5 pt-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md w-fit border border-white/15">
            <span className="w-2 h-2 rounded-full bg-[#6ffbbe] animate-ping" />
            <span className="text-xs font-semibold uppercase tracking-wider text-[#6ffbbe]">
              Authentic Island Journeys • Southern Coast &amp; Hill Country
            </span>
          </div>

          <h1 className="font-['Outfit'] text-4xl sm:text-5xl lg:text-6xl text-white font-bold tracking-tight leading-[1.15]">
            Explore Sri Lanka with{' '}
            <span className="text-[#ffddb8] underline decoration-[#006c49] decoration-4 underline-offset-8">
              MC Travel &amp; Tours
            </span>
          </h1>

          <p className="text-base sm:text-lg text-[#b5c8e5] max-w-2xl leading-relaxed">
            Discover breathtaking destinations, experience authentic Sri Lankan culture, and enjoy the pure freedom of exploring the island your way—from curated private tours to coastal bike rentals.
          </p>

          {/* CTA Row */}
          <div className="flex flex-wrap items-center gap-3.5 pt-3">
            <button
              onClick={onExploreTours}
              className="inline-flex items-center gap-2 px-6 py-3.5 bg-[#006c49] text-white rounded-lg text-sm font-semibold hover:bg-[#6ffbbe] hover:text-[#002113] shadow-lg shadow-[#006c49]/25 transition-all hover:-translate-y-0.5 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">explore</span>
              <span>Explore Our Tours</span>
            </button>

            <button
              onClick={onRentBike}
              className="inline-flex items-center gap-2 px-6 py-3.5 bg-[#0d2137] text-white rounded-lg text-sm font-semibold hover:bg-white/20 backdrop-blur-md shadow-md border border-white/10 transition-all hover:-translate-y-0.5 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">two_wheeler</span>
              <span>Rent a Bike</span>
            </button>

            <a
              href="https://wa.me/94771234567?text=Hello%20MC%20Travel%20%26%20Tours,%20I%20would%20like%20to%20inquire%20about%20your%20island%20tours%20and%20bike%20rentals."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-3.5 bg-[#6ffbbe] text-[#002113] rounded-lg text-sm font-semibold hover:bg-[#006c49] hover:text-white transition-all shadow-md"
            >
              <span className="material-symbols-outlined text-[20px]">chat</span>
              <span>Chat on WhatsApp</span>
            </a>
          </div>
        </div>

        {/* Trust Badges Floating Grid */}
        <div className="mt-14 pt-6 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 border-t border-white/10">
          <div className="flex items-center gap-3 p-3.5 rounded-xl bg-white/5 backdrop-blur-lg border border-white/10 hover:bg-white/10 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-[#006c49]/30 flex items-center justify-center shrink-0 text-[#6ffbbe]">
              <span className="material-symbols-outlined text-[22px]">tune</span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-bold text-white leading-tight">100% Tailored</span>
              <span className="text-xs text-[#b5c8e5]">Bespoke Island Routes</span>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3.5 rounded-xl bg-white/5 backdrop-blur-lg border border-white/10 hover:bg-white/10 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-[#ffddb8]/30 flex items-center justify-center shrink-0 text-[#ffddb8]">
              <span className="material-symbols-outlined text-[22px]">badge</span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-bold text-white leading-tight">Local Drivers</span>
              <span className="text-xs text-[#b5c8e5]">Experienced &amp; Friendly</span>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3.5 rounded-xl bg-white/5 backdrop-blur-lg border border-white/10 hover:bg-white/10 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-[#006c49]/30 flex items-center justify-center shrink-0 text-[#6ffbbe]">
              <span className="material-symbols-outlined text-[22px]">motorcycle</span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-bold text-white leading-tight">Maintained Fleet</span>
              <span className="text-xs text-[#b5c8e5]">Checked Daily</span>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3.5 rounded-xl bg-white/5 backdrop-blur-lg border border-white/10 hover:bg-white/10 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-[#ffddb8]/30 flex items-center justify-center shrink-0 text-[#ffddb8]">
              <span className="material-symbols-outlined text-[22px]">support_agent</span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-bold text-white leading-tight">Quick Support</span>
              <span className="text-xs text-[#b5c8e5]">Instant WhatsApp Chat</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
