import React from 'react';
import { SERVICES_LIST } from '../data/mockData';

interface ServicesProps {
  onSelectCategory: (category: string) => void;
  onNavigate: (hash: string) => void;
}

export const Services: React.FC<ServicesProps> = ({ onSelectCategory, onNavigate }) => {
  const handleAction = (service: typeof SERVICES_LIST[0]) => {
    if (service.target === '#booking') {
      onSelectCategory(service.category);
    } else {
      onNavigate(service.target);
    }
  };

  return (
    <section className="w-full py-20 bg-[#f3f3f4]" id="services">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col gap-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="w-8 h-0.5 bg-[#006c49]" />
              <span className="text-xs uppercase tracking-widest text-[#006c49] font-bold">
                End-to-End Travel Logistics
              </span>
            </div>
            <h2 className="font-['Outfit'] text-3xl md:text-4xl text-[#000917] font-bold tracking-tight">
              Our Services
            </h2>
            <p className="text-sm md:text-base text-[#44474d]">
              Comprehensive travel solutions for seamless island travel across Sri Lanka.
            </p>
          </div>

          <button
            onClick={() => onSelectCategory('Customized Private Tour')}
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#006c49] hover:text-[#000917] transition-colors cursor-pointer"
          >
            <span>Custom Travel Inquiry</span>
            <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
          </button>
        </div>

        {/* 8 Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {SERVICES_LIST.map((service, idx) => (
            <div
              key={idx}
              className={`group bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between border ${
                service.popular ? 'border-[#006c49]/30 relative' : 'border-[#eeeeee]'
              }`}
            >
              <div className="flex flex-col gap-4">
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                    service.popular
                      ? 'bg-[#ffddb8] text-[#2a1700]'
                      : 'bg-[#6ffbbe]/40 text-[#002113] group-hover:bg-[#006c49] group-hover:text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-[26px]">{service.icon}</span>
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <h3 className="font-['Outfit'] font-semibold text-lg text-[#000917]">
                      {service.title}
                    </h3>
                    {service.popular && (
                      <span className="px-2 py-0.5 rounded-full bg-[#6ffbbe] text-[11px] font-bold text-[#002113]">
                        Popular
                      </span>
                    )}
                  </div>
                  <p className="text-xs sm:text-sm text-[#44474d] mt-1.5 leading-relaxed">
                    {service.desc}
                  </p>
                </div>
              </div>

              <button
                onClick={() => handleAction(service)}
                className="mt-6 inline-flex items-center gap-1.5 text-xs font-semibold text-[#006c49] group-hover:translate-x-1 transition-transform cursor-pointer"
              >
                <span>{service.actionLabel}</span>
                <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
