import React from 'react';
import { BikeModel } from '../types';

interface BikeDetailModalProps {
  bike: BikeModel | null;
  onClose: () => void;
  onSelectBike: (bikeName: string, rate: number) => void;
  currency: string;
  formatPrice: (usd: number) => string;
}

export const BikeDetailModal: React.FC<BikeDetailModalProps> = ({
  bike,
  onClose,
  onSelectBike,
  formatPrice
}) => {
  if (!bike) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#000917]/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col border border-[#c4c6cd]/30">
        <div className="relative h-60 w-full shrink-0 overflow-hidden bg-[#e8e8e8]">
          <img
            src={bike.imageUrl}
            alt={bike.imageAlt}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#000917]/80 via-transparent to-transparent" />

          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/20 hover:bg-white text-white hover:text-[#000917] flex items-center justify-center backdrop-blur-md transition-colors"
            aria-label="Close dialog"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>

          <div className="absolute bottom-4 left-6 right-6 flex items-end justify-between text-white">
            <div>
              <span className="px-2.5 py-0.5 rounded-full bg-[#6ffbbe] text-[11px] font-bold text-[#002113]">
                {bike.type}
              </span>
              <h3 className="font-['Outfit'] text-2xl font-bold mt-1">{bike.name}</h3>
            </div>
            <div className="text-right">
              <span className="text-xs text-white/80 block">Standard Rate</span>
              <span className="font-['Outfit'] font-bold text-2xl text-[#6ffbbe]">
                {formatPrice(bike.ratePerDay)} <span className="text-xs font-normal text-white">/ day</span>
              </span>
            </div>
          </div>
        </div>

        <div className="p-6 overflow-y-auto flex flex-col gap-5">
          {/* Technical Specs Matrix */}
          <div>
            <h4 className="text-xs uppercase tracking-wider text-[#006c49] font-bold mb-3">
              Expedition Specifications
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-[#f9f9f9] border border-[#eeeeee] flex flex-col">
                <span className="text-[11px] text-[#44474d]/80">Engine</span>
                <span className="font-bold text-sm text-[#000917] mt-0.5">{bike.engine}</span>
              </div>
              <div className="p-3 rounded-xl bg-[#f9f9f9] border border-[#eeeeee] flex flex-col">
                <span className="text-[11px] text-[#44474d]/80">Transmission</span>
                <span className="font-bold text-sm text-[#000917] mt-0.5">{bike.transmission}</span>
              </div>
              <div className="p-3 rounded-xl bg-[#f9f9f9] border border-[#eeeeee] flex flex-col">
                <span className="text-[11px] text-[#44474d]/80">Fuel Tank</span>
                <span className="font-bold text-sm text-[#000917] mt-0.5">{bike.fuelCapacity}</span>
              </div>
              <div className="p-3 rounded-xl bg-[#f9f9f9] border border-[#eeeeee] flex flex-col">
                <span className="text-[11px] text-[#44474d]/80">Security Deposit</span>
                <span className="font-bold text-sm text-[#000917] mt-0.5">{bike.deposit}</span>
              </div>
            </div>
          </div>

          {/* Riding recommendation */}
          <div className="p-4 rounded-xl bg-[#f3f3f4] border border-[#e8e8e8] flex flex-col gap-1.5">
            <span className="text-xs font-bold text-[#000917] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px] text-[#006c49]">recommend</span>
              <span>Ideal Riding Conditions</span>
            </span>
            <p className="text-xs sm:text-sm text-[#44474d] leading-relaxed">
              {bike.idealFor}
            </p>
          </div>

          {/* Complimentary gear */}
          <div className="flex items-center gap-3 text-xs text-[#44474d] bg-[#f9f9f9] p-3 rounded-xl border border-[#eeeeee]">
            <span className="material-symbols-outlined text-[20px] text-[#006c49]">sports_motorsports</span>
            <span>Includes 2x DOT-certified sanitized helmets, cellphone handlebar mount, and 24/7 coastal breakdown assistance.</span>
          </div>

          {/* Action Row */}
          <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#eeeeee]">
            <button
              onClick={onClose}
              className="py-2.5 px-4 rounded-lg bg-[#eeeeee] text-[#000917] text-xs font-semibold hover:bg-[#e2e2e2] transition-colors"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onSelectBike(bike.name, bike.ratePerDay);
              }}
              className="py-2.5 px-6 rounded-lg bg-[#006c49] text-white text-xs font-semibold hover:bg-[#000917] transition-colors shadow-md flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[18px]">calculate</span>
              <span>Calculate Rental Quote</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
