import React from 'react';

interface FooterProps {
  onOpenLegal: (type: 'terms' | 'privacy' | 'safety') => void;
  onNavigate: (href: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenLegal, onNavigate }) => {
  return (
    <footer className="w-full bg-[#000917] text-white pt-16 pb-12 border-t border-white/10">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          {/* Brand Col */}
          <div className="lg:col-span-2 flex flex-col gap-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#ffffff] flex items-center justify-center">
                <span className="material-symbols-outlined text-[#006c49] text-[20px]">
                  travel_explore
                </span>
              </div>
              <span className="font-['Outfit'] font-bold text-2xl tracking-tight text-white">
                MC Travel &amp; Tours
              </span>
            </div>

            <p className="text-xs sm:text-sm text-[#b5c8e5] max-w-md leading-relaxed">
              Curated motorcycle expeditions and bespoke luxury tropical journeys across Sri Lanka. Experience the teardrop isle through pristine coastal roads, misty highland tea estates, and ancient kingdoms.
            </p>

            <div className="flex items-center gap-2.5 pt-1">
              <a
                href="#destinations"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('#destinations');
                }}
                aria-label="Explore Destinations"
                className="w-9 h-9 rounded-full bg-[#0d2137] text-[#d2e4ff] flex items-center justify-center hover:bg-[#006c49] hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined text-[18px]">public</span>
              </a>
              <a
                href="#gallery"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('#gallery');
                }}
                aria-label="Photo Gallery"
                className="w-9 h-9 rounded-full bg-[#0d2137] text-[#d2e4ff] flex items-center justify-center hover:bg-[#006c49] hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined text-[18px]">photo_camera</span>
              </a>
              <a
                href="#packages"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('#packages');
                }}
                aria-label="Tour Packages"
                className="w-9 h-9 rounded-full bg-[#0d2137] text-[#d2e4ff] flex items-center justify-center hover:bg-[#006c49] hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined text-[18px]">explore</span>
              </a>
              <a
                href="https://wa.me/94771234567"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instant WhatsApp Channel"
                className="w-9 h-9 rounded-full bg-[#0d2137] text-[#6ffbbe] flex items-center justify-center hover:bg-[#006c49] hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined text-[18px]">forum</span>
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="flex flex-col gap-3">
            <h3 className="font-['Outfit'] font-bold text-sm text-[#ffddb8] uppercase tracking-wider">
              Quick Links
            </h3>
            <ul className="flex flex-col gap-2 text-xs text-[#b5c8e5]">
              <li>
                <a
                  href="#about"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#about');
                  }}
                  className="hover:text-white transition-colors"
                >
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#services');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Our Services
                </a>
              </li>
              <li>
                <a
                  href="#packages"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#packages');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Tour Packages
                </a>
              </li>
              <li>
                <a
                  href="#destinations"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#destinations');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Island Destinations
                </a>
              </li>
              <li>
                <a
                  href="#gallery"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#gallery');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Expedition Gallery
                </a>
              </li>
              <li>
                <a
                  href="#reviews"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#reviews');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Guest Testimonials
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Fleet & Tours */}
          <div className="flex flex-col gap-3">
            <h3 className="font-['Outfit'] font-bold text-sm text-[#ffddb8] uppercase tracking-wider">
              Fleet &amp; Tours
            </h3>
            <ul className="flex flex-col gap-2 text-xs text-[#b5c8e5]">
              <li>
                <a
                  href="#bikerental"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#bikerental');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Royal Enfield Classic 350
                </a>
              </li>
              <li>
                <a
                  href="#bikerental"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#bikerental');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Honda PCX Maxi-Scooter
                </a>
              </li>
              <li>
                <a
                  href="#bikerental"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#bikerental');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Coastal Cruiser Scooters
                </a>
              </li>
              <li>
                <a
                  href="#packages"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#packages');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Highland Tea Trail (3-4D)
                </a>
              </li>
              <li>
                <a
                  href="#packages"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#packages');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Southern Surf Loop (2-3D)
                </a>
              </li>
              <li>
                <a
                  href="#packages"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('#packages');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Complete Island Circuit (7-10D)
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact Concierge */}
          <div className="flex flex-col gap-3">
            <h3 className="font-['Outfit'] font-bold text-sm text-[#ffddb8] uppercase tracking-wider">
              Contact Concierge
            </h3>
            <div className="flex flex-col gap-2 text-xs text-[#b5c8e5]">
              <div className="flex items-start gap-2">
                <span className="material-symbols-outlined text-[16px] text-[#6ffbbe] shrink-0 mt-0.5">
                  location_on
                </span>
                <span>Galle Road, Weligama Bay &amp; Colombo Central, Sri Lanka</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] text-[#6ffbbe] shrink-0">
                  call
                </span>
                <a href="tel:+94771234567" className="hover:text-white">
                  +94 (77) 123-4567
                </a>
              </div>
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] text-[#6ffbbe] shrink-0">
                  mail
                </span>
                <a href="mailto:concierge@mctraveltours.com" className="hover:text-white">
                  concierge@mctraveltours.com
                </a>
              </div>
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] text-[#6ffbbe] shrink-0">
                  schedule
                </span>
                <span>Daily: 07:00 – 21:00 IST</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#b5c8e5]">
          <div className="flex items-center gap-2 text-center md:text-left">
            <span>
              © 2025 MC Travel &amp; Tours (Pvt) Ltd. All rights reserved. Sri Lanka Tourism Dev Auth Reg #SLTDA/SQA/PRO/00491.
            </span>
          </div>

          <div className="flex items-center gap-6">
            <button
              onClick={() => onOpenLegal('terms')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Terms of Rental
            </button>
            <button
              onClick={() => onOpenLegal('privacy')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <button
              onClick={() => onOpenLegal('safety')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Rider Safety Charter
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
