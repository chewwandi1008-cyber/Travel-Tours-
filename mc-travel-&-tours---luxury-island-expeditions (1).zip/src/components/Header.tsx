import React, { useState, useEffect } from 'react';

interface HeaderProps {
  onOpenBooking: () => void;
  currency: string;
  setCurrency: (c: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenBooking, currency, setCurrency }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About Us', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Tour Packages', href: '#packages' },
    { label: 'Destinations', href: '#destinations' },
    { label: 'Bike Rental', href: '#bikerental' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Contact', href: '#contact' }
  ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#f9f9f9]/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.06)]'
          : 'bg-[#f9f9f9]/85 backdrop-blur-md shadow-[0_1px_4px_rgba(0,0,0,0.03)]'
      }`}
    >
      <div className="h-20 w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex items-center justify-between gap-6">
        {/* Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick('#home');
            }}
            className="flex items-center gap-2.5 group"
          >
            <div className="h-9 w-9 rounded-lg bg-[#000917] flex items-center justify-center text-white font-bold text-base shadow-sm group-hover:bg-[#006c49] transition-colors">
              <span className="material-symbols-outlined text-[20px] text-[#6ffbbe]">travel_explore</span>
            </div>
            <div className="flex flex-col">
              <span className="font-['Outfit'] font-semibold text-[20px] text-[#000917] tracking-tight leading-none group-hover:text-[#006c49] transition-colors">
                MC Travel
              </span>
              <span className="text-[10px] text-[#44474d] tracking-widest uppercase font-semibold">
                Tours &amp; Fleet Sri Lanka
              </span>
            </div>
          </a>
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden xl:flex items-center gap-6 text-[14px] font-semibold text-[#44474d]">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                handleNavClick(link.href);
              }}
              className="hover:text-[#006c49] transition-colors whitespace-nowrap"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Currency Switcher */}
          <div className="relative inline-flex items-center">
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="px-2 py-1.5 rounded-lg bg-[#eeeeee] border border-[#c4c6cd]/50 text-xs font-semibold text-[#000917] focus:outline-none focus:border-[#006c49] cursor-pointer"
              title="Select display currency"
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="LKR">LKR (Rs)</option>
            </select>
          </div>

          {/* WhatsApp CTA */}
          <a
            href="https://wa.me/94771234567?text=Hello%20MC%20Travel%20%26%20Tours,%20I%20would%20like%20to%20inquire%20about%20island%20tours%20and%20bike%20rentals."
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#6ffbbe] text-[#002113] rounded-lg text-xs font-semibold hover:bg-[#006c49] hover:text-white transition-all shadow-[0_2px_6px_rgba(0,108,73,0.12)] whitespace-nowrap"
          >
            <span className="material-symbols-outlined text-[16px]">chat</span>
            <span>WhatsApp</span>
          </a>

          {/* Primary Book CTA */}
          <button
            onClick={onOpenBooking}
            className="inline-flex items-center justify-center px-4 py-2 bg-[#ffddb8] text-[#2a1700] text-xs sm:text-sm font-semibold rounded-lg hover:bg-[#ffb95f] transition-all shadow-[0_4px_14px_rgba(255,185,95,0.25)] hover:-translate-y-0.5 whitespace-nowrap"
          >
            Book Now
          </button>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden w-9 h-9 rounded-lg bg-[#eeeeee] flex items-center justify-center text-[#000917] hover:bg-[#e2e2e2] transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            <span className="material-symbols-outlined text-[22px]">
              {mobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#ffffff] border-b border-[#e2e2e2] shadow-xl px-6 py-5 flex flex-col gap-3">
          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-[#eeeeee]">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                className="py-2 px-3 rounded-lg text-sm font-semibold text-[#44474d] hover:bg-[#f3f3f4] hover:text-[#006c49] transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>
          <div className="flex items-center gap-3 pt-2">
            <a
              href="https://wa.me/94771234567"
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 py-2.5 px-4 bg-[#6ffbbe] text-[#002113] rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[18px]">chat</span>
              <span>WhatsApp Chat</span>
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking();
              }}
              className="flex-1 py-2.5 px-4 bg-[#000917] text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <span>Book Journey</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
