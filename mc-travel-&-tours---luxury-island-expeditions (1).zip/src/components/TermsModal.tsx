import React from 'react';

interface TermsModalProps {
  type: 'terms' | 'privacy' | 'safety' | null;
  onClose: () => void;
}

export const TermsModal: React.FC<TermsModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  const content = {
    terms: {
      title: 'Terms of Rental & Island Exploration',
      subtitle: 'Official Guidelines for Motorcycle, Scooter & Chauffeur Services',
      sections: [
        {
          heading: '1. Driver Eligibility & Licensing',
          text: 'Riders must possess a valid domestic motorcycle license alongside an official International Driving Permit (IDP) or a recognized temporary Sri Lankan driving endorsement issued by the Automobile Association of Ceylon (AA Ceylon). We assist all incoming international travellers with this simple paperwork upon arrival.'
        },
        {
          heading: '2. Security Deposit & Returns',
          text: 'A refundable security deposit ($50 to $150 USD depending on vehicle class) or valid passport is held in our hotel-grade physical safe during the rental tenure. The vehicle must be returned with the same fuel level as recorded at handover.'
        },
        {
          heading: '3. Breakdown Support & Regional Range',
          text: 'All bikes come with 24/7 on-road mechanical assistance across the Southern Province (Galle, Mirissa, Weligama, Tangalle, Matara) and Hill Country (Ella, Haputale, Nuwara Eliya). In the rare case of a puncture or mechanical failure, our mobile technician will be dispatched to your location.'
        }
      ]
    },
    privacy: {
      title: 'Privacy & Data Protection Policy',
      subtitle: 'How MC Travel & Tours Safeguards Your Personal Information',
      sections: [
        {
          heading: '1. Information Collected',
          text: 'We only collect essential contact information (Full Name, Phone/WhatsApp, Email, Hotel Pickup Location) and travel preferences strictly required to coordinate transfers, permits, and vehicle delivery.'
        },
        {
          heading: '2. Third-Party Confidentiality',
          text: 'We never sell, trade, or share your contact details with external commercial third parties. Your data is used exclusively by our internal concierge desk and licensed drivers.'
        },
        {
          heading: '3. Secure Communication',
          text: 'Booking inquiries submitted via our web app are encrypted in transit directly to our verified business communication channels.'
        }
      ]
    },
    safety: {
      title: 'Island Rider Safety Charter',
      subtitle: 'Essential Guidelines for Navigating Sri Lankan Roads Safely',
      sections: [
        {
          heading: '1. Helmet Discipline is Mandatory',
          text: 'Both rider and pillion passenger must always fasten DOT-certified helmets whenever the motorcycle is in motion. Helmets are provided sanitized with every hire.'
        },
        {
          heading: '2. Left-Hand Traffic & Highway Etiquette',
          text: 'Traffic in Sri Lanka moves on the LEFT side of the road. Always yield right of way to buses and commercial vehicles on narrow coastal roads. Never ride on the Southern Expressway (E01) on two wheels, as motorcycles are legally prohibited on toll expressways.'
        },
        {
          heading: '3. Wildlife & Coastal Hazards',
          text: 'Watch for stray dogs, monitor lizards, and peacocks crossing coastal routes, especially around Weligama, Tangalle, and Yala perimeter roads. Reduce speed in wet weather after tropical rain showers.'
        }
      ]
    }
  };

  const activeContent = content[type];

  return (
    <div className="fixed inset-0 z-50 bg-[#000917]/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl p-6 md:p-8 flex flex-col gap-6 max-h-[90vh] overflow-y-auto border border-[#eeeeee]">
        <div className="flex items-start justify-between pb-3 border-b border-[#eeeeee]">
          <div>
            <h3 className="font-['Outfit'] text-2xl font-bold text-[#000917]">
              {activeContent.title}
            </h3>
            <p className="text-xs text-[#006c49] font-semibold mt-1">
              {activeContent.subtitle}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#eeeeee] hover:bg-[#e2e2e2] flex items-center justify-center text-[#000917] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <div className="flex flex-col gap-4 text-xs sm:text-sm text-[#44474d] leading-relaxed">
          {activeContent.sections.map((sec, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-[#f9f9f9] border border-[#eeeeee] flex flex-col gap-1.5">
              <h4 className="font-bold text-sm text-[#000917]">{sec.heading}</h4>
              <p>{sec.text}</p>
            </div>
          ))}
        </div>

        <div className="flex justify-end pt-2 border-t border-[#eeeeee]">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-lg bg-[#000917] text-white text-xs font-semibold hover:bg-[#006c49] transition-colors cursor-pointer"
          >
            Understood &amp; Close
          </button>
        </div>
      </div>
    </div>
  );
};
