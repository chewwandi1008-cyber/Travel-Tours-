import React from 'react';
import { WHY_US_CARDS } from '../data/mockData';

export const WhyUs: React.FC = () => {
  return (
    <section className="w-full py-20 bg-[#000917] text-white relative overflow-hidden" id="why-us">
      <div className="absolute -bottom-24 -right-24 w-96 h-96 rounded-full bg-[#006c49]/10 blur-3xl pointer-events-none" />

      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col gap-10 relative z-10">
        <div className="max-w-2xl flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <span className="w-8 h-0.5 bg-[#6ffbbe]" />
            <span className="text-xs uppercase tracking-widest text-[#6ffbbe] font-bold">
              Why Travel With Us
            </span>
          </div>
          <h2 className="font-['Outfit'] text-3xl md:text-4xl text-white font-bold tracking-tight">
            Straightforward, Reliable Island Exploration
          </h2>
          <p className="text-sm md:text-base text-[#b5c8e5]">
            We focus on what matters most to our travellers: honest advice, clean transport, and local attentiveness without high markups.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WHY_US_CARDS.map((card, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 flex flex-col gap-3 hover:bg-white/10 transition-colors"
            >
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  card.color === 'secondary'
                    ? 'bg-[#006c49]/30 text-[#6ffbbe]'
                    : 'bg-[#ffddb8]/30 text-[#ffddb8]'
                }`}
              >
                <span className="material-symbols-outlined text-[24px]">{card.icon}</span>
              </div>
              <h3 className="font-['Outfit'] font-bold text-lg text-white">
                {card.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#b5c8e5] leading-relaxed">
                {card.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
