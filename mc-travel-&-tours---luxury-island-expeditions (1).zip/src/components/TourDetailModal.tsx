import React from 'react';
import { TourPackage } from '../types';

interface TourDetailModalProps {
  pkg: TourPackage | null;
  onClose: () => void;
  onRequestQuote: (packageName: string) => void;
}

export const TourDetailModal: React.FC<TourDetailModalProps> = ({
  pkg,
  onClose,
  onRequestQuote
}) => {
  if (!pkg) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#000917]/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col border border-[#c4c6cd]/30">
        {/* Header Image with close button */}
        <div className="relative h-64 sm:h-72 w-full shrink-0 overflow-hidden bg-[#e8e8e8]">
          <img
            src={pkg.imageUrl}
            alt={pkg.imageAlt}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#000917]/90 via-[#000917]/40 to-transparent" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/20 hover:bg-white text-white hover:text-[#000917] flex items-center justify-center backdrop-blur-md transition-colors"
            aria-label="Close dialog"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>

          {/* Title & Duration in Image */}
          <div className="absolute bottom-5 left-6 right-6 flex flex-col gap-1 text-white">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-[#6ffbbe] text-[11px] font-bold text-[#002113]">
                {pkg.category}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-semibold text-white">
                {pkg.duration}
              </span>
            </div>
            <h3 className="font-['Outfit'] text-2xl sm:text-3xl font-bold tracking-tight">
              {pkg.title}
            </h3>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 sm:p-8 overflow-y-auto flex flex-col gap-6">
          <div>
            <h4 className="text-xs uppercase tracking-wider text-[#006c49] font-bold">
              Expedition Overview
            </h4>
            <p className="text-sm sm:text-base text-[#44474d] mt-1.5 leading-relaxed">
              {pkg.description}
            </p>
          </div>

          {/* Day by Day Itinerary */}
          {pkg.itineraryDays && pkg.itineraryDays.length > 0 && (
            <div className="flex flex-col gap-3">
              <h4 className="text-xs uppercase tracking-wider text-[#006c49] font-bold">
                Suggested Day-by-Day Schedule
              </h4>
              <div className="flex flex-col gap-3">
                {pkg.itineraryDays.map((step, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-[#f9f9f9] border border-[#eeeeee] flex flex-col gap-2">
                    <div className="flex items-center gap-2 text-sm font-bold text-[#000917]">
                      <span className="px-2 py-0.5 rounded bg-[#000917] text-white text-xs">
                        {step.day}
                      </span>
                      <span>{step.title}</span>
                    </div>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                      {step.highlights.map((hl, hIdx) => (
                        <li key={hIdx} className="flex items-center gap-1.5 text-xs text-[#44474d]">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#006c49] shrink-0" />
                          <span>{hl}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Inclusions */}
          {pkg.included && pkg.included.length > 0 && (
            <div className="p-4 rounded-xl bg-[#f3f3f4] border border-[#e8e8e8] flex flex-col gap-2">
              <span className="text-xs font-bold text-[#000917] uppercase tracking-wider flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[18px] text-[#006c49]">check_circle</span>
                <span>Included in this Expedition</span>
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-[#44474d] pt-1">
                {pkg.included.map((item, iIdx) => (
                  <div key={iIdx} className="flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[16px] text-[#006c49]">done</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Pricing Note & Actions */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-[#eeeeee]">
            <div>
              <span className="text-xs text-[#44474d] block">Pricing Guidance:</span>
              <span className="font-['Outfit'] font-bold text-lg text-[#000917]">
                {pkg.pricingNote}
              </span>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={onClose}
                className="flex-1 sm:flex-none py-2.5 px-4 rounded-lg bg-[#eeeeee] text-[#000917] text-xs font-semibold hover:bg-[#e2e2e2] transition-colors"
              >
                Close
              </button>
              <button
                onClick={() => {
                  onClose();
                  onRequestQuote(`${pkg.title} (${pkg.duration})`);
                }}
                className="flex-1 sm:flex-none py-2.5 px-6 rounded-lg bg-[#006c49] text-white text-xs font-semibold hover:bg-[#000917] transition-colors shadow-md flex items-center justify-center gap-1.5"
              >
                <span className="material-symbols-outlined text-[18px]">send</span>
                <span>Request Custom Quote</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
