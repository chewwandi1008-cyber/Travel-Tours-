import React, { useState } from 'react';

export const ContactSection: React.FC = () => {
  const [selectedHub, setSelectedHub] = useState<'galle' | 'weligama' | 'colombo'>('galle');

  const hubDetails = {
    galle: {
      name: 'Galle Fort Flagship Station',
      address: 'No. 42 Light House Street, Galle Fort, Southern Province',
      hours: '07:00 AM – 10:00 PM Daily',
      phone: '+94 (77) 123-4567',
      fleet: 'Complete Scooter & Royal Enfield Fleet Available'
    },
    weligama: {
      name: 'Weligama Surf & Coastal Station',
      address: 'Pelena Coastal Bypass, Weligama Bay, Sri Lanka',
      hours: '06:30 AM – 09:30 PM Daily',
      phone: '+94 (77) 123-4568',
      fleet: 'Scooter Fleet with Surfboard Racks & Beach Delivery'
    },
    colombo: {
      name: 'Colombo Airport Transit Desk',
      address: 'Bandaranaike International Airport (BIA) Katunayake & Colombo 03',
      hours: '24/7 Advance Booking Meet & Greet',
      phone: '+94 (77) 123-4569',
      fleet: 'Chauffeur Driven Sedans, Vans, Airport Shuttles'
    }
  };

  const active = hubDetails[selectedHub];

  return (
    <section className="w-full py-20 bg-[#f3f3f4]" id="contact">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col gap-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
          {/* Left Contact Info */}
          <div className="lg:col-span-5 flex flex-col justify-between gap-6">
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <span className="w-8 h-0.5 bg-[#006c49]" />
                <span className="text-xs uppercase tracking-widest text-[#006c49] font-bold">
                  Get In Touch
                </span>
              </div>
              <h2 className="font-['Outfit'] text-3xl md:text-4xl text-[#000917] font-bold tracking-tight">
                Contact Concierge
              </h2>
              <p className="text-sm md:text-base text-[#44474d]">
                Have questions about vehicle availability, road conditions, or airport pickups? Reach out through our direct channels anytime.
              </p>
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white shadow-sm border border-[#eeeeee]">
                <div className="w-10 h-10 rounded-xl bg-[#6ffbbe]/40 text-[#002113] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[22px]">pin_drop</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-[#000917]">Operating Hubs</span>
                  <span className="text-xs text-[#44474d]">
                    Galle Road, Weligama Bay &amp; Colombo Central Hub, Sri Lanka
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white shadow-sm border border-[#eeeeee]">
                <div className="w-10 h-10 rounded-xl bg-[#6ffbbe]/40 text-[#002113] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[22px]">call</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-[#000917]">Telephone Inquiries</span>
                  <a href="tel:+94771234567" className="text-xs text-[#006c49] font-semibold hover:underline">
                    +94 (77) 123-4567
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white shadow-sm border border-[#eeeeee]">
                <div className="w-10 h-10 rounded-xl bg-[#6ffbbe]/40 text-[#002113] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[22px]">mail</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-[#000917]">Email Concierge</span>
                  <a href="mailto:concierge@mctraveltours.com" className="text-xs text-[#006c49] font-semibold hover:underline">
                    concierge@mctraveltours.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white shadow-sm border border-[#eeeeee]">
                <div className="w-10 h-10 rounded-xl bg-[#6ffbbe]/40 text-[#002113] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[22px]">schedule</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-[#000917]">Working Hours</span>
                  <span className="text-xs text-[#44474d]">Daily: 07:00 AM – 10:00 PM (IST)</span>
                </div>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://wa.me/94771234567"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-3 px-4 rounded-xl bg-[#006c49] text-white flex items-center justify-center gap-2 text-xs font-semibold hover:bg-[#6ffbbe] hover:text-[#002113] transition-colors shadow-md"
              >
                <span className="material-symbols-outlined text-[20px]">chat</span>
                <span>Open WhatsApp</span>
              </a>
              <a
                href="tel:+94771234567"
                className="py-3 px-5 rounded-xl bg-[#000917] text-white flex items-center justify-center gap-2 text-xs font-semibold hover:bg-[#006c49] transition-colors"
              >
                <span className="material-symbols-outlined text-[20px]">call</span>
                <span>Direct Call</span>
              </a>
            </div>
          </div>

          {/* Right Stylized Interactive Map Placeholder & Branch Switcher */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            {/* Hub tabs */}
            <div className="flex items-center gap-2 bg-white p-1.5 rounded-xl border border-[#eeeeee] w-fit">
              <button
                onClick={() => setSelectedHub('galle')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  selectedHub === 'galle' ? 'bg-[#000917] text-white shadow-sm' : 'text-[#44474d] hover:bg-[#f3f3f4]'
                }`}
              >
                Galle Fort Hub
              </button>
              <button
                onClick={() => setSelectedHub('weligama')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  selectedHub === 'weligama' ? 'bg-[#000917] text-white shadow-sm' : 'text-[#44474d] hover:bg-[#f3f3f4]'
                }`}
              >
                Weligama Beach
              </button>
              <button
                onClick={() => setSelectedHub('colombo')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  selectedHub === 'colombo' ? 'bg-[#000917] text-white shadow-sm' : 'text-[#44474d] hover:bg-[#f3f3f4]'
                }`}
              >
                Colombo BIA Desk
              </button>
            </div>

            {/* Map Frame */}
            <div className="w-full h-[360px] sm:h-[400px] rounded-3xl overflow-hidden shadow-xl bg-[#e8e8e8] relative border border-[#eeeeee]">
              <div
                className="w-full h-full bg-cover bg-center transition-all duration-700"
                style={{
                  backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXuCLf29kBfhtQx6DVexA2shgw0qsbVE7r0gEofzXb9ktNGcEu7kA0gaFh5OP7i2ozWqpvSUJ2VnPe20H3-94w-7ZHhTdz7EfNYRWNNdTrokVWLdD6zJWmhTNAN1ky9vTxZQP0jOU5Us7QTnx960TLLil1ZK5IP2n8EASijfWLhlagNPUpSvEUpfhgs7jyBKZOW2G52RemTpyN0GGLU30zH5sVX_7j6ldyeIOuzqk9YqH10W7oNkaNvvv')`
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#000917]/70 via-transparent to-transparent pointer-events-none" />

              {/* Overlay Pin Card */}
              <div className="absolute bottom-6 left-6 right-6 sm:right-auto bg-white/95 backdrop-blur-md p-4 rounded-xl shadow-xl flex items-start gap-3 max-w-sm border border-white">
                <div className="w-10 h-10 rounded-lg bg-[#006c49] text-white flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[20px]">place</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-['Outfit'] font-bold text-sm text-[#000917]">
                    {active.name}
                  </span>
                  <p className="text-xs text-[#44474d] mt-0.5">
                    {active.address}
                  </p>
                  <span className="text-[11px] text-[#006c49] font-semibold mt-1">
                    {active.hours}
                  </span>
                </div>
              </div>
            </div>

            <p className="text-xs text-[#44474d] text-center">
              * Bike pick-ups and vehicle returns are coordinated directly at our Galle hub or delivered to your coastal hotel upon reservation.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
