import React, { useState, useEffect } from 'react';

interface BookingSectionProps {
  initialCategory?: string;
  initialSelection?: string;
}

export const BookingSection: React.FC<BookingSectionProps> = ({
  initialCategory = 'Sri Lanka Tour Package',
  initialSelection = ''
}) => {
  const [fullName, setFullName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [category, setCategory] = useState<string>(initialCategory);
  const [selection, setSelection] = useState<string>(initialSelection);
  const [travelDate, setTravelDate] = useState<string>('');
  const [pax, setPax] = useState<string>('2 Travelers (Couple)');
  const [message, setMessage] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (initialCategory) setCategory(initialCategory);
  }, [initialCategory]);

  useEffect(() => {
    if (initialSelection) setSelection(initialSelection);
  }, [initialSelection]);

  useEffect(() => {
    const today = new Date();
    today.setDate(today.getDate() + 7);
    const pad = (n: number) => (n < 10 ? '0' + n : n);
    setTravelDate(`${today.getFullYear()}-${pad(today.getMonth() + 1)}-${pad(today.getDate())}`);
  }, []);

  const buildWhatsAppText = () => {
    return (
      `*New Travel Booking Inquiry - MC Travel & Tours*\n\n` +
      `*Customer Name:* ${fullName}\n` +
      `*Email:* ${email}\n` +
      `*Phone/WhatsApp:* ${phone}\n` +
      `*Service Type:* ${category}\n` +
      `*Requested Tour / Bike:* ${selection || 'Open to recommendation'}\n` +
      `*Preferred Date:* ${travelDate}\n` +
      `*Travelers:* ${pax}\n` +
      `*Details & Notes:* ${message || 'No special requests noted.'}\n\n` +
      `_Looking forward to your quote and guidance!_`
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSuccess(true);
    const rawText = buildWhatsAppText();
    const encoded = encodeURIComponent(rawText);
    setTimeout(() => {
      window.open(`https://wa.me/94771234567?text=${encoded}`, '_blank');
    }, 300);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(buildWhatsAppText());
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section className="w-full py-20 bg-[#f3f3f4]" id="booking">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col gap-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
          {/* Left: Context & Direct Contact Details */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <span className="w-8 h-0.5 bg-[#006c49]" />
                <span className="text-xs uppercase tracking-widest text-[#006c49] font-bold">
                  Fast &amp; Personal
                </span>
              </div>
              <h2 className="font-['Outfit'] text-3xl md:text-4xl text-[#000917] font-bold tracking-tight">
                Plan Your Journey
              </h2>
              <p className="text-sm md:text-base text-[#44474d] leading-relaxed">
                Tell us your preferred dates, destination, or vehicle of choice. We craft a personalized itinerary and send an instant quote directly via WhatsApp or email.
              </p>
            </div>

            <div className="flex flex-col gap-3 p-5 rounded-2xl bg-white shadow-sm border border-[#eeeeee]">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#006c49]/10 text-[#006c49] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[22px]">bolt</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-[#000917]">Rapid Response Time</span>
                  <span className="text-xs text-[#44474d]">
                    We usually reply within 15–30 minutes during Sri Lankan business hours (07:00 – 21:00 IST).
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3 pt-2 border-t border-[#eeeeee]">
                <div className="w-10 h-10 rounded-lg bg-[#ffddb8]/40 text-[#2a1700] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[22px]">price_check</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-[#000917]">No Hidden Fees</span>
                  <span className="text-xs text-[#44474d]">
                    Fuel policies, chauffeur allowances, and deposit terms are completely transparent.
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3 pt-2 border-t border-[#eeeeee]">
                <div className="w-10 h-10 rounded-lg bg-[#6ffbbe]/40 text-[#002113] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[22px]">forum</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-[#000917]">Direct WhatsApp Link</span>
                  <span className="text-xs text-[#44474d]">
                    This form compiles your exact requirements into a pre-filled WhatsApp message.
                  </span>
                </div>
              </div>
            </div>

            {/* Direct hotline callout */}
            <div className="p-4 rounded-xl bg-[#000917] text-white flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-[24px] text-[#6ffbbe]">headset_mic</span>
                <div>
                  <span className="text-xs text-[#b5c8e5] block">Prefer to talk directly?</span>
                  <a href="tel:+94771234567" className="font-bold text-sm text-white hover:text-[#6ffbbe] transition-colors">
                    +94 (77) 123-4567
                  </a>
                </div>
              </div>
              <a
                href="tel:+94771234567"
                className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-colors"
              >
                Call Concierge
              </a>
            </div>
          </div>

          {/* Right: Inquiry Form */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 md:p-10 shadow-xl border border-[#c4c6cd]/30 flex flex-col gap-5">
            {isSuccess && (
              <div className="p-4 rounded-xl bg-[#6ffbbe]/40 border border-[#006c49]/30 text-[#002113] flex flex-col gap-2 animate-fadeIn">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[24px] text-[#006c49]">check_circle</span>
                  <span className="text-sm font-bold">Inquiry prepared successfully!</span>
                </div>
                <p className="text-xs text-[#002113]">
                  Your WhatsApp message has been generated and dispatched. If your browser blocked popups, you can copy the text below:
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={handleCopy}
                    className="px-3 py-1.5 rounded-md bg-[#000917] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[14px]">content_copy</span>
                    <span>{copied ? 'Copied to Clipboard!' : 'Copy Inquiry Text'}</span>
                  </button>
                  <a
                    href={`https://wa.me/94771234567?text=${encodeURIComponent(buildWhatsAppText())}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-md bg-[#006c49] text-white text-xs font-semibold"
                  >
                    Open WhatsApp Again
                  </a>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Full Name */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#000917]" htmlFor="bookFullName">
                  Full Name *
                </label>
                <input
                  id="bookFullName"
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Sarah Jenkins"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
                />
              </div>

              {/* Email */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#000917]" htmlFor="bookEmail">
                  Email Address *
                </label>
                <input
                  id="bookEmail"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="sarah@example.com"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
                />
              </div>

              {/* Phone / WhatsApp */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#000917]" htmlFor="bookPhone">
                  Telephone / WhatsApp *
                </label>
                <input
                  id="bookPhone"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+1 555 123 4567"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
                />
              </div>

              {/* Service Category */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#000917]" htmlFor="bookCategory">
                  Service Category *
                </label>
                <select
                  id="bookCategory"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917] cursor-pointer"
                >
                  <option value="Sri Lanka Tour Package">Sri Lanka Tour Package</option>
                  <option value="Customized Private Tour">Customized Private Tour</option>
                  <option value="Airport Transfer (BIA / Mattala)">Airport Transfer (BIA / Mattala)</option>
                  <option value="Private Car/Van with Driver">Private Car/Van with Driver</option>
                  <option value="Bike & Scooter Rental">Bike &amp; Scooter Rental</option>
                  <option value="Custom Multi-Day Itinerary">Custom Multi-Day Itinerary</option>
                </select>
              </div>

              {/* Selected Tour or Bike */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#000917]" htmlFor="bookSelection">
                  Selected Tour / Bike Model
                </label>
                <input
                  id="bookSelection"
                  type="text"
                  value={selection}
                  onChange={(e) => setSelection(e.target.value)}
                  placeholder="e.g. Galle Fort (1-2 Days) or Royal Enfield"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
                />
              </div>

              {/* Preferred Date */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#000917]" htmlFor="bookDate">
                  Preferred Travel / Start Date *
                </label>
                <input
                  id="bookDate"
                  type="date"
                  required
                  value={travelDate}
                  onChange={(e) => setTravelDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
                />
              </div>

              {/* Number of Travelers */}
              <div className="md:col-span-2 flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#000917]" htmlFor="bookPax">
                  Number of Travelers / Riders *
                </label>
                <select
                  id="bookPax"
                  value={pax}
                  onChange={(e) => setPax(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917] cursor-pointer"
                >
                  <option value="1 Solo Rider / Traveler">1 Solo Traveler / Rider</option>
                  <option value="2 Travelers (Couple)">2 Travelers (Couple)</option>
                  <option value="3-4 Travelers (Family / Small Group)">3-4 Travelers (Family / Small Group)</option>
                  <option value="5-8 Travelers (Spacious Van)">5-8 Travelers (Spacious Passenger Van)</option>
                  <option value="8+ Large Group">8+ Large Group / Custom Fleet</option>
                </select>
              </div>

              {/* Special Requests */}
              <div className="md:col-span-2 flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#000917]" htmlFor="bookMessage">
                  Special Requests &amp; Details
                </label>
                <textarea
                  id="bookMessage"
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us if you need child safety seats, hotel pickup in Galle/Colombo, specific surfboard racks for your scooter, or scenic train tickets..."
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
                />
              </div>

              {/* Submit Button */}
              <div className="md:col-span-2 pt-2">
                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-[#006c49] text-white hover:bg-[#000917] transition-all text-sm font-semibold flex items-center justify-center gap-2 shadow-lg shadow-[#006c49]/20 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px]">send</span>
                  <span>Submit &amp; Generate WhatsApp Inquiry</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
