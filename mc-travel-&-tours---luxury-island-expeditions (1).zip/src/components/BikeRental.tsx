import React, { useState, useEffect } from 'react';
import { BIKE_FLEET } from '../data/mockData';
import { BikeModel } from '../types';

interface BikeRentalProps {
  onOpenBikeModal: (bike: BikeModel) => void;
  currency: string;
  formatPrice: (usd: number) => string;
}

export const BikeRental: React.FC<BikeRentalProps> = ({
  onOpenBikeModal,
  currency,
  formatPrice
}) => {
  const [selectedBikeModel, setSelectedBikeModel] = useState<string>('Honda Dio 110cc');
  const [pickupLocation, setPickupLocation] = useState<string>('Galle Fort Hub');
  const [returnLocation, setReturnLocation] = useState<string>('Galle Fort Hub');
  const [pickupDate, setPickupDate] = useState<string>('');
  const [returnDate, setReturnDate] = useState<string>('');
  const [fullName, setFullName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [showSuccessAlert, setShowSuccessAlert] = useState<boolean>(false);

  // Set default dates on mount
  useEffect(() => {
    const now = new Date();
    now.setHours(9, 0, 0, 0);
    const future = new Date(now);
    future.setDate(future.getDate() + 3);

    const pad = (n: number) => (n < 10 ? '0' + n : n);
    const formatDt = (d: Date) =>
      `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;

    setPickupDate(formatDt(now));
    setReturnDate(formatDt(future));
  }, []);

  const activeBike = BIKE_FLEET.find((b) => b.name === selectedBikeModel) || BIKE_FLEET[0];

  // Calculate duration & total
  const calculateDays = () => {
    if (!pickupDate || !returnDate) return 1;
    const start = new Date(pickupDate).getTime();
    const end = new Date(returnDate).getTime();
    const diff = end - start;
    if (diff <= 0) return 1;
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return Math.max(1, days);
  };

  const rentalDays = calculateDays();
  const estimatedTotal = rentalDays * activeBike.ratePerDay;

  const handlePrefillBike = (bikeName: string) => {
    setSelectedBikeModel(bikeName);
    const calcSection = document.getElementById('bikeRentalCalcForm');
    if (calcSection) {
      calcSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleRentalSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const formattedMessage =
      `*Bike Rental Inquiry - MC Travel & Tours*%0A%0A` +
      `*Name:* ${encodeURIComponent(fullName)}%0A` +
      `*Phone/WhatsApp:* ${encodeURIComponent(phone)}%0A` +
      `*Email:* ${encodeURIComponent(email)}%0A` +
      `*Bike Selected:* ${encodeURIComponent(selectedBikeModel)}%0A` +
      `*Pickup Location:* ${encodeURIComponent(pickupLocation)}%0A` +
      `*Return Location:* ${encodeURIComponent(returnLocation)}%0A` +
      `*Pickup Date/Time:* ${encodeURIComponent(pickupDate)}%0A` +
      `*Return Date/Time:* ${encodeURIComponent(returnDate)}%0A` +
      `*Rental Duration:* ${encodeURIComponent(`${rentalDays} Day${rentalDays > 1 ? 's' : ''}`)}%0A` +
      `*Estimated Cost:* ${encodeURIComponent(formatPrice(estimatedTotal))}%0A` +
      `*Deposit Rule:* ${encodeURIComponent(activeBike.deposit)}%0A%0A` +
      `_Please confirm availability and booking requirements._`;

    setShowSuccessAlert(true);
    setTimeout(() => {
      window.open(`https://wa.me/94771234567?text=${formattedMessage}`, '_blank');
    }, 400);
  };

  return (
    <section className="w-full py-20 bg-[#f3f3f4]" id="bikerental">
      <div className="w-full max-w-[1360px] mx-auto px-4 md:px-8 lg:px-12 flex flex-col gap-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#6ffbbe]/30 w-fit text-[#002113] text-xs font-bold uppercase tracking-wider">
              <span className="material-symbols-outlined text-[16px]">two_wheeler</span>
              <span>Freedom on Two Wheels</span>
            </div>
            <h2 className="font-['Outfit'] text-3xl md:text-4xl text-[#000917] font-bold tracking-tight">
              Bike &amp; Scooter Rental Fleet
            </h2>
            <p className="text-sm md:text-base text-[#44474d]">
              Explore scenic coastal curves and highland hill climbs on our maintained fleet of scooters and road bikes. Helmets included, transparent deposits, and pickup in Galle or airport delivery on request.
            </p>
          </div>

          <div className="flex flex-col gap-1 md:text-right">
            <span className="text-xs sm:text-sm font-bold text-[#006c49]">
              Daily Rates from {formatPrice(15)} / day
            </span>
            <span className="text-xs text-[#44474d]">
              Helmets &amp; Emergency Support included
            </span>
          </div>
        </div>

        {/* Fleet Grid Showcase (5 Models) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {BIKE_FLEET.map((bike) => (
            <div
              key={bike.id}
              className={`bg-white rounded-2xl p-4 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between border ${
                bike.badgeType === 'signature'
                  ? 'border-[#ffb95f]/60 bg-gradient-to-b from-[#ffddb8]/10 to-white'
                  : 'border-[#eeeeee]'
              }`}
            >
              <div className="flex flex-col gap-3">
                <div className="relative h-40 w-full rounded-xl bg-[#e8e8e8] overflow-hidden group">
                  <img
                    src={bike.imageUrl}
                    alt={bike.imageAlt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <span
                    className={`absolute top-2 right-2 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      bike.badgeType === 'signature'
                        ? 'bg-[#ffddb8] text-[#2a1700]'
                        : bike.badgeType === 'limited'
                        ? 'bg-[#ffb95f] text-[#2a1700]'
                        : 'bg-[#6ffbbe] text-[#002113]'
                    }`}
                  >
                    {bike.badge}
                  </span>

                  <button
                    onClick={() => onOpenBikeModal(bike)}
                    className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/60 backdrop-blur-sm text-white text-[10px] hover:bg-black transition-colors"
                  >
                    Specs &amp; Photos
                  </button>
                </div>

                <div>
                  <span className="text-[10px] text-[#44474d] uppercase tracking-wider">
                    {bike.type}
                  </span>
                  <h3 className="font-['Outfit'] font-semibold text-base text-[#000917]">
                    {bike.name}
                  </h3>
                  <p className="font-['Outfit'] text-xl text-[#006c49] font-bold mt-0.5">
                    {formatPrice(bike.ratePerDay)}{' '}
                    <span className="text-xs font-normal text-[#44474d]">/ day</span>
                  </p>
                </div>

                {/* Specs mini matrix */}
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  <div className="p-2 rounded bg-[#f3f3f4] flex flex-col">
                    <span className="text-[10px] text-[#44474d]">Engine</span>
                    <span className="font-bold text-[11px] text-[#000917] truncate">{bike.engine}</span>
                  </div>
                  <div className="p-2 rounded bg-[#f3f3f4] flex flex-col">
                    <span className="text-[10px] text-[#44474d]">Deposit</span>
                    <span className="font-bold text-[11px] text-[#000917] truncate">{bike.deposit}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 flex flex-col gap-1.5">
                <button
                  onClick={() => handlePrefillBike(bike.name)}
                  className="w-full py-2 rounded-lg bg-[#eeeeee] hover:bg-[#006c49] hover:text-white text-[#000917] text-xs font-semibold transition-colors cursor-pointer"
                >
                  Select for Quote
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Rental Guidelines Box */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 p-6 rounded-2xl bg-white shadow-sm border border-[#eeeeee]">
          <div className="flex items-start gap-3">
            <span className="material-symbols-outlined text-[24px] text-[#006c49] shrink-0 mt-0.5">
              sports_motorsports
            </span>
            <div>
              <span className="font-bold text-sm text-[#000917]">Helmets &amp; Safety Gear</span>
              <p className="text-xs text-[#44474d] mt-1 leading-relaxed">
                Two sanitized DOT-certified helmets included with every rental at no additional charge.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <span className="material-symbols-outlined text-[24px] text-[#006c49] shrink-0 mt-0.5">
              assignment_ind
            </span>
            <div>
              <span className="font-bold text-sm text-[#000917]">Driving License &amp; IDP</span>
              <p className="text-xs text-[#44474d] mt-1 leading-relaxed">
                Valid International Driving Permit (IDP) or local endorsement required for Sri Lankan roads.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <span className="material-symbols-outlined text-[24px] text-[#006c49] shrink-0 mt-0.5">
              lock
            </span>
            <div>
              <span className="font-bold text-sm text-[#000917]">Simple Security Deposit</span>
              <p className="text-xs text-[#44474d] mt-1 leading-relaxed">
                Refundable cash deposit or original passport held securely in our safe during your trip.
              </p>
            </div>
          </div>
        </div>

        {/* INTERACTIVE BIKE RENTAL CALCULATOR FORM */}
        <div className="bg-white rounded-3xl p-6 md:p-10 shadow-xl border border-[#c4c6cd]/30 flex flex-col gap-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-2 border-b border-[#eeeeee]">
            <div>
              <h3 className="font-['Outfit'] text-xl md:text-2xl font-bold text-[#000917]">
                Interactive Rental Price Calculator
              </h3>
              <p className="text-xs md:text-sm text-[#44474d]">
                Estimate your rental duration and total cost, then generate an instant WhatsApp inquiry.
              </p>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#6ffbbe]/40 text-[#002113] text-xs font-semibold self-start md:self-auto">
              <span className="material-symbols-outlined text-[16px]">bolt</span>
              <span>Instant Rate Estimation</span>
            </div>
          </div>

          {showSuccessAlert && (
            <div className="p-4 rounded-xl bg-[#6ffbbe]/30 border border-[#006c49]/30 text-[#002113] flex items-center justify-between gap-3 animate-fadeIn">
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-[22px] text-[#006c49]">check_circle</span>
                <span className="text-xs sm:text-sm font-semibold">
                  Rental request compiled! Opening your WhatsApp chat with MC Travel Concierge...
                </span>
              </div>
              <button
                onClick={() => setShowSuccessAlert(false)}
                className="text-xs text-[#44474d] hover:text-[#000917]"
              >
                Dismiss
              </button>
            </div>
          )}

          <form id="bikeRentalCalcForm" onSubmit={handleRentalSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Name */}
            <div className="md:col-span-4 flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-[#000917]" htmlFor="calcName">
                Your Full Name *
              </label>
              <input
                id="calcName"
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. Alex Henderson"
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
              />
            </div>

            {/* Phone */}
            <div className="md:col-span-4 flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-[#000917]" htmlFor="calcPhone">
                Phone / WhatsApp Number *
              </label>
              <input
                id="calcPhone"
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+44 7911 123456"
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
              />
            </div>

            {/* Email */}
            <div className="md:col-span-4 flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-[#000917]" htmlFor="calcEmail">
                Email Address *
              </label>
              <input
                id="calcEmail"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="alex@traveler.com"
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
              />
            </div>

            {/* Bike selection */}
            <div className="md:col-span-6 flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-[#000917]" htmlFor="calcBike">
                Preferred Bike / Scooter *
              </label>
              <select
                id="calcBike"
                value={selectedBikeModel}
                onChange={(e) => setSelectedBikeModel(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917] cursor-pointer"
              >
                {BIKE_FLEET.map((bike) => (
                  <option key={bike.id} value={bike.name}>
                    {bike.name} ({formatPrice(bike.ratePerDay)} / day) - {bike.type}
                  </option>
                ))}
              </select>
            </div>

            {/* Pickup Location */}
            <div className="md:col-span-3 flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-[#000917]" htmlFor="calcPickupLoc">
                Pickup Location *
              </label>
              <select
                id="calcPickupLoc"
                value={pickupLocation}
                onChange={(e) => setPickupLocation(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917] cursor-pointer"
              >
                <option value="Galle Fort Hub">Galle Fort Hub</option>
                <option value="Mirissa Beach">Mirissa Beach</option>
                <option value="Weligama Bay">Weligama Bay</option>
                <option value="Colombo Airport (BIA)">Colombo Airport (BIA)</option>
                <option value="Negombo Beach">Negombo Beach</option>
                <option value="Bentota">Bentota</option>
                <option value="Kandy Town">Kandy Town</option>
                <option value="Ella Mountain Station">Ella Mountain Station</option>
              </select>
            </div>

            {/* Return Location */}
            <div className="md:col-span-3 flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-[#000917]" htmlFor="calcReturnLoc">
                Return Location *
              </label>
              <select
                id="calcReturnLoc"
                value={returnLocation}
                onChange={(e) => setReturnLocation(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917] cursor-pointer"
              >
                <option value="Galle Fort Hub">Galle Fort Hub</option>
                <option value="Mirissa Beach">Mirissa Beach</option>
                <option value="Weligama Bay">Weligama Bay</option>
                <option value="Colombo Airport (BIA)">Colombo Airport (BIA)</option>
                <option value="Negombo Beach">Negombo Beach</option>
                <option value="Bentota">Bentota</option>
                <option value="Kandy Town">Kandy Town</option>
                <option value="Ella Mountain Station">Ella Mountain Station</option>
              </select>
            </div>

            {/* Pickup Date & Time */}
            <div className="md:col-span-6 flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-[#000917]" htmlFor="calcPickupDate">
                Pickup Date &amp; Time *
              </label>
              <input
                id="calcPickupDate"
                type="datetime-local"
                required
                value={pickupDate}
                onChange={(e) => setPickupDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
              />
            </div>

            {/* Return Date & Time */}
            <div className="md:col-span-6 flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-[#000917]" htmlFor="calcReturnDate">
                Return Date &amp; Time *
              </label>
              <input
                id="calcReturnDate"
                type="datetime-local"
                required
                value={returnDate}
                onChange={(e) => setReturnDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#f9f9f9] border border-[#c4c6cd] focus:outline-none focus:border-[#006c49] text-sm text-[#000917]"
              />
            </div>

            {/* Calculation Summary Box */}
            <div className="md:col-span-12 p-5 rounded-2xl bg-[#eeeeee] flex flex-col md:flex-row md:items-center justify-between gap-5 mt-2">
              <div className="flex flex-wrap items-center gap-6">
                <div className="flex flex-col">
                  <span className="text-[10px] text-[#44474d] uppercase tracking-wider font-bold">
                    Estimated Duration
                  </span>
                  <span className="font-['Outfit'] text-xl text-[#000917] font-bold">
                    {rentalDays} {rentalDays === 1 ? 'Day' : 'Days'}
                  </span>
                </div>

                <div className="hidden sm:block w-px h-10 bg-[#c4c6cd]" />

                <div className="flex flex-col">
                  <span className="text-[10px] text-[#44474d] uppercase tracking-wider font-bold">
                    Daily Rate
                  </span>
                  <span className="font-['Outfit'] text-xl text-[#000917] font-bold">
                    {formatPrice(activeBike.ratePerDay)} / day
                  </span>
                </div>

                <div className="hidden sm:block w-px h-10 bg-[#c4c6cd]" />

                <div className="flex flex-col">
                  <span className="text-[10px] text-[#44474d] uppercase tracking-wider font-bold">
                    Estimated Total
                  </span>
                  <span className="font-['Outfit'] text-2xl text-[#006c49] font-bold">
                    {formatPrice(estimatedTotal)}
                  </span>
                </div>
              </div>

              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-[#006c49] text-white rounded-lg text-sm font-semibold hover:bg-[#6ffbbe] hover:text-[#002113] shadow-md transition-all cursor-pointer whitespace-nowrap"
              >
                <span className="material-symbols-outlined text-[20px]">chat</span>
                <span>Send WhatsApp Rental Request</span>
              </button>
            </div>

            <div className="md:col-span-12">
              <p className="text-xs text-[#44474d] italic">
                * Note: Inquiries do not automatically confirm reservations. Final availability, rental conditions, and prices are confirmed directly by MC Travel &amp; Tours staff upon contact.
              </p>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
