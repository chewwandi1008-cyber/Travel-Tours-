import { TourPackage, BikeModel, Destination, GalleryItem, Testimonial } from '../types';

export const TOUR_PACKAGES: TourPackage[] = [
  {
    id: 'galle-fort',
    title: 'Galle Fort & Southern Coast',
    category: 'Southern Coast',
    duration: '1-2 Days',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAhMO3sRRyXYjZaHoxUNGWYUvH6IPq9bsZWoiVTT25D2u88yYLcHKhU00Uho26O1WZQT0HYUxOJ2fPp8Mc5b13gHBcQd7gVGAmCiBblX50olrjKaLzeEbWiTJYim_hv4mBqpugCfRXHCNt9QP43qLlr-f8gqeF-S1xkq-2MZM0Om_2NH8stJUjSTt43dGFQVNseba3xWddlLvlHmsf1pM5HYMHExBY3hZAiNsFJIAKwssP0exiw5o6k',
    imageAlt: 'Galle Dutch Fort ramparts overlooking the emerald ocean at sunset with the iconic white lighthouse and coconut palms in Sri Lanka.',
    description: 'Dutch colonial ramparts, maritime museums, artisanal cafes, and coastal turtle hatcheries.',
    tags: ['Heritage Walk', 'Lighthouse', 'Dutch Architecture'],
    pricingNote: 'Custom Quote (Typically $70 - $120 / day)',
    itineraryDays: [
      {
        day: 'Day 1',
        title: 'Dutch Fort Exploration & Sunset Ramparts',
        highlights: ['Guided walk through 17th-century ramparts', 'Visit the iconic white Galle Lighthouse', 'Artisan cafes and Dutch Hospital precinct dinner']
      },
      {
        day: 'Day 2',
        title: 'Coastal Turtles & Jungle Beach',
        highlights: ['Kosgoda Sea Turtle Conservation sanctuary', 'Japanese Peace Pagoda view', 'Afternoon swim at tranquil Jungle Beach']
      }
    ],
    included: ['Private AC Sedan or Van', 'Licensed English-Speaking Chauffeur', 'Fuel, Tolls & Parking', 'Hotel Pickup & Drop in Southern Province']
  },
  {
    id: 'hikkaduwa-beach',
    title: 'Hikkaduwa Beach Experience',
    category: 'Beach & Snorkel',
    duration: '2-3 Days',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCRQGUWyOcPNbAFfPcvOfRk455YelZDDylAJU8F7u9GPAFTzwh03s5R3mlPfELEsfPrqaQDRW8lxN78C_K9NrOfxDuFg1lFw-CbOaaAf8-m-zThVfPrtwDEnd1s44m9mdkv_FzraIJ2nFm5jdYBszBbSC-m4qjtDlXRlG1kJlG-JgCULPJ170DMK6mqIOVXUCvRNi5GKDc_fPPAzTZB1BlTIE1LYZO5RJdAygDFE08ktpVXVCWoNm6u',
    imageAlt: 'Hikkaduwa beach coastline with clear turquoise waters, surfers catching small clean waves and swimmers snorkelling over shallow coral reefs.',
    description: 'Vibrant coral reef snorkeling, sea turtle feeding points, water sports, and sunset seafood dining.',
    tags: ['Coral Reef', 'Water Sports', 'Sea Turtles'],
    pricingNote: 'Custom Quote (Includes Snorkel Gear Options)',
    itineraryDays: [
      {
        day: 'Day 1',
        title: 'Coral Sanctuary & Giant Wild Turtles',
        highlights: ['Morning snorkeling at Hikkaduwa Marine National Park', 'Feeding wild green sea turtles on the shore', 'Fresh seafood beachfront dinner']
      },
      {
        day: 'Day 2',
        title: 'Surfing & Coastal Lagoons',
        highlights: ['Beginner/Intermediate surf session with certified coach', 'Madu Ganga river boat safari through mangrove tunnels', 'Cinnamon island demonstration']
      }
    ],
    included: ['Private Vehicle with Driver', 'Mask & Snorkel Sets', 'Boat Safari Tickets', 'Cold Bottled Water']
  },
  {
    id: 'ella-hill-country',
    title: 'Ella & Hill Country Adventure',
    category: 'Hill Country',
    duration: '3-4 Days',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAsn3wTNfdv1ethLTzqSghUwZ_aVsSzRp5P5n1GpXB5Y678Gz6FnD3SfaLTgjdMp20Mc77RNWXeUEzRbjHajQ1n6I7ktd9N-3wvhe0_l7GuOtqhGc5_TeGGXgouECIMusfErnYUysCOYm53AewM360q_m1f4Dd34oT07LHTvKQXS6-T1Dk-Xz3X3dGzkLhPBXRaH_A0Phipdo68w1U_pFJIIdaOWZZInCU1KFkMa9eK5BIwbyWBVxdZ',
    imageAlt: 'Iconic Nine Arch Bridge in Ella surrounded by dense emerald jungle and tea hills with the blue Sri Lankan train crossing.',
    description: "Nine Arch Bridge, Little Adam's Peak sunrise hike, Ravana Falls, and tea factory experiences.",
    tags: ['Hiking', 'Waterfalls', 'Scenic Train'],
    pricingNote: 'Custom Quote (Scenic Train Tickets Arranged)',
    itineraryDays: [
      {
        day: 'Day 1',
        title: 'Arrival via Scenic Mountain Passes',
        highlights: ['Drive past cascading Ravana Falls', 'Check-in to mountain lodge overlooking Ella Gap', 'Cafe chill in Ella town']
      },
      {
        day: 'Day 2',
        title: 'Nine Arch Bridge & Little Adam\'s Peak',
        highlights: ['Watch iconic blue train cross the Nine Arch Viaduct', 'Hike Little Adam\'s Peak for 360-degree views', 'Flying Ravana mega zipline option']
      },
      {
        day: 'Day 3',
        title: 'Tea Estate & Highland Heritage',
        highlights: ['Organic Ceylon tea factory tour & tasting', 'Lipton\'s Seat panoramic viewpoint excursion', 'Traditional Sri Lankan home-cooked lunch']
      }
    ],
    included: ['Dedicated Vehicle & Driver throughout', 'Scenic Observation Train Booking Support', 'Highland Driver Lodging & Allowance', 'Factory Entry Passes']
  },
  {
    id: 'kandy-cultural',
    title: 'Kandy Cultural Tour',
    category: 'Sacred Heritage',
    duration: '2 Days',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCpesKRZCiVOMPltfIbZxh6zXJx99lnUTPt2tuA6CNkgr11wDvnrHwVHDx3pmtUd59VDixAZhLwK7y-bEWlgIHrBPNlLtjtGoVy44e1VjdRXau3NUpPPD6YAIh2am-Sqg-pY0DC0xkgeFebaDKsoLCFZO8pQHzO6IsIDTU7Oc4VfyBHT009vIQY_0IcRpG1QHFdT-aiUuYeHynx0tVCt3anTIT8BZmXVRrOxS35oYdNaoWmFKk6tv4e',
    imageAlt: 'Temple of the Sacred Tooth Relic in Kandy Sri Lanka viewed across the tranquil Kandy Lake with surrounding mist-covered green hills.',
    description: 'Temple of the Sacred Tooth Relic, Royal Botanical Gardens Peradeniya, and cultural dance performances.',
    tags: ['Cultural Dance', 'Lake Walk', 'Sacred Temple'],
    pricingNote: 'Custom Quote',
    itineraryDays: [
      {
        day: 'Day 1',
        title: 'The Sacred Tooth Relic & Royal City',
        highlights: ['Evening Puja ceremony at Sri Dalada Maligawa', 'Traditional Kandyan drumming & dance performance', 'Stroll around illuminated Kandy Lake']
      },
      {
        day: 'Day 2',
        title: 'Royal Botanical Gardens & Spice Trails',
        highlights: ['Peradeniya Royal Botanical Gardens giant palms & orchid house', 'Gem museum and lapidary demonstration', 'Spicy Ceylon tea tasting overlooking the valley']
      }
    ],
    included: ['Private Chauffeur-Guide', 'Temple Dress Code Consultation', 'All Parking & Highway Tolls']
  },
  {
    id: 'sigiriya-heritage',
    title: 'Sigiriya & Ancient Heritage',
    category: 'Ancient Triangle',
    duration: '2-3 Days',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCp4oVHIhKDWa8ru63YyfPFJAO1rVSWJwzF5-ERa5k3sd1BYH8iEPgxGj4eEJDbvbW8GIT6tLp_yWv0iGbLhzJ988OvTnMyq-Y5Qq6CqhlN_IiUP10WieV1n6tgJnVIRt6C9Hq0PPljjmCwlT7RUXEL7HdIDtm0ABSx29gWXPUfk4zS8jikCDzlNk50aoecOyDtdXBSpLZDC09kHSkDsAguyTUex4bMY4-V48jArTMeyIdg0oNb02wr',
    imageAlt: 'The grand Sigiriya Lion Rock fortress rising majestically over lush central plains of Sri Lanka during golden morning hour.',
    description: 'Climb Sigiriya Lion Rock fortress, explore Dambulla Cave Temple murals, and experience rural village tours.',
    tags: ['Lion Rock', 'Cave Temples', 'UNESCO World Heritage'],
    pricingNote: 'Custom Quote',
    itineraryDays: [
      {
        day: 'Day 1',
        title: 'Dambulla Golden Cave Temple',
        highlights: ['Climb to rock-hewn caves with 150+ gilded Buddha statues', 'Ancient ceiling frescoes preserved across 2,000 years', 'Sunset over Kandalama Reservoir']
      },
      {
        day: 'Day 2',
        title: 'Sigiriya 5th Century Citadel',
        highlights: ['Early morning ascent of Sigiriya Lion Rock', 'Marvel at mirror wall & legendary cloud maiden frescoes', 'Bullock cart & catamaran village experience']
      }
    ],
    included: ['Experienced Driver Guide', 'Cold Mineral Water in Vehicle', 'Local Village Lunch Experience']
  },
  {
    id: 'yala-wildlife',
    title: 'Yala Wildlife Adventure',
    category: 'Wildlife Safari',
    duration: '2 Days',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDxEQmIz-bcBL31GOTL5p9LzSzsilztRJK4cn04PtNlv23k4rup_yOaHYzhOlWTwuZukAgiNHjesRVlyrpYC2sjrPIB1slen8EWmOeaLQmKYAxvfpjyrbMxHAGe2fwAn50ehnwWcFwBJ_y1O010YRbLhTgZX7d7lxXyzcx2dbSifs-5rUYDA8nJAQefy04S-A-jlY4yNeJmKv_aupzrRRYTvki8dq9INPsVnpHuxXPn-pv-Z9YeWjR-',
    imageAlt: 'Wild Sri Lankan leopard resting peacefully on a large boulder in Yala National Park surrounded by dry zone thorny shrubs under bright daylight.',
    description: '4x4 open-top jeep safari to spot Sri Lankan leopards, sloth bears, wild elephants, and coastal lagoons.',
    tags: ['4x4 Safari', 'Leopards', 'Birdwatching'],
    pricingNote: 'Custom Quote (Includes Safari Jeep & Trackers)',
    itineraryDays: [
      {
        day: 'Day 1',
        title: 'Tissamaharama & Afternoon Game Drive',
        highlights: ['Afternoon 4x4 safari through Block 1', 'Search for Asian elephants and basking mugger crocodiles', 'Stargazing at safari glamping camp']
      },
      {
        day: 'Day 2',
        title: 'Dawn Leopard Tracking',
        highlights: ['Pre-dawn entry into prime leopard territory', 'Spotting endemic jungle fowl and hornbills', 'Scenic breakfast picnic beside Patanangala beach']
      }
    ],
    included: ['Modified High-Clearance 4x4 Jeep', 'Licensed Wildlife Department Tracker', 'National Park Entrance Fees', 'Binoculars for Wildlife Viewing']
  },
  {
    id: 'mirissa-coastal',
    title: 'Mirissa Coastal & Whales',
    category: 'Marine & Coastal',
    duration: '2-3 Days',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCYuA9nIgiC9ZYFYyKQfjACnA7VXux0tUvJAkRxEpZhIz70sPTyIx9Og1-leyTFk8BvPSqnjhblMJg1ORJqIjiZwItQnVKxddzRYcJE7w6gYBNS2Wmd2uTrBHwcAyhvceH8unvCSPVa6-unkUhFQNHzVmFD9m3_Wd0dTHLiiixLDI3BoiZZdHhjJc4Xrsu8-uOsYVGmdL_4UZ96dOwHpsIcwoWeLwGUgnbU4EeLGZ_aXuY6vF5XvMfk',
    imageAlt: 'Mirissa Coconut Tree Hill with tall bent palm trees looking over the Indian Ocean during warm tropical twilight in Sri Lanka.',
    description: 'Early morning blue whale watching boat excursion, Coconut Tree Hill sunset, and lively beachside dining.',
    tags: ['Whale Watching', 'Surf & Sunset', 'Coconut Hill'],
    pricingNote: 'Custom Quote',
    itineraryDays: [
      {
        day: 'Day 1',
        title: 'Blue Whale Watching Expedition',
        highlights: ['Early boat charter to continental shelf for Blue Whales and Spinner Dolphins', 'Coconut Tree Hill panoramic twilight photography', 'Fresh catch candlelit beach dinner']
      },
      {
        day: 'Day 2',
        title: 'Secret Beach & Snorkeling',
        highlights: ['Explore secluded Secret Beach cove', 'Paddleboarding in Weligama Bay', 'Sunset rooftop cocktails']
      }
    ],
    included: ['Marine Life Boat Cruise Tickets', 'Breakfast onboard vessel', 'AC Transfers between Hotel & Harbor']
  },
  {
    id: 'complete-island',
    title: 'Complete Island Tour',
    category: 'Ultimate Experience',
    duration: '7-10 Days',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBt4R0Lfz31YebSVp6iVlz9xwsg2tJRArnt6niHGcPf3sFOuCqf0E_EY8H5Ypf14VMHXYKkcYBsWtfgGZBqlgb7MH-6ZyTQUwsmv8XTOqsYEWvF4wTcX_pv788lsZVgSbFKpbmK8iAMtw7m9dGBjyn_KA-JuYrcdFy0PSH9iyrh3CkEO7YcvzFUE08oBC3jWA8-UdDMwb9OeVWXdeMqDbqg_nH_5Vld51RDzvj3JJROFlncocNeCFHY',
    imageAlt: 'A montage of Sri Lankan scenery showing misty green tea valleys of Nuwara Eliya, golden beaches and ancient Buddhist stupas under clear blue sky.',
    description: 'The comprehensive journey: Cultural Triangle, Kandy, Nuwara Eliya, Ella, Yala Safari, and Galle Coast.',
    tags: ['Full Circuit', 'Coast & Hills', 'Signature Journey'],
    pricingNote: 'Custom Quote (All Inclusive Vehicle & Chauffeur)',
    itineraryDays: [
      { day: 'Day 1-2', title: 'Arrival & Cultural Triangle', highlights: ['Airport pickup, Sigiriya Rock Fortress, Dambulla Caves'] },
      { day: 'Day 3-4', title: 'Kandy & Nuwara Eliya', highlights: ['Temple of the Tooth, Royal Botanical Gardens, Tea plantations'] },
      { day: 'Day 5-6', title: 'Ella & Yala National Park', highlights: ['Nine Arch Bridge, Little Adam\'s Peak, 4x4 Leopard Safari'] },
      { day: 'Day 7-10', title: 'Galle & Southern Coastlines', highlights: ['Mirissa whale watching, Galle Fort ramparts, Colombo drop-off'] }
    ],
    included: ['Dedicated Chauffeur & Modern AC Vehicle for entire duration', 'Airport Pickup & Drop-off', 'Chauffeur Accommodation & Meals', 'All Fuel, Tolls & Parking Permits']
  }
];

export const BIKE_FLEET: BikeModel[] = [
  {
    id: 'honda-dio',
    name: 'Honda Dio 110cc',
    type: 'Automatic Scooter',
    ratePerDay: 15,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDKqKx2p8gRsr6wRF-ocEjuUO3yPcL1zB9P_6Q5Ugl8_2RxYZHlTTVbjD2PGW0lWlYwsZzBiwMAwEdHxC_wJQ9J7SkVQLHXN2rYnqhFokJeB6A3WRxW0JnELFysgpBAg7FIw3ydZMY8HH9lsE4lQLFMJzRLxKk7qBxThHqSHlJqTWTTLJUnQbrEyAu5tuItnz44KdTdDk-plorIdDSHrD6BshhEOcXQu3rM5jRv-RyhbDV4Nm-FWjLH',
    imageAlt: 'Red Honda Dio 110cc automatic scooter parked by tropical palm trees in Sri Lanka with ocean in background.',
    badge: 'Available',
    badgeType: 'available',
    engine: '110cc Automatic',
    deposit: '$50 or Passport',
    transmission: 'CVT Automatic Twist-and-Go',
    fuelCapacity: '5.3 Liters (Approx 45 km/L)',
    idealFor: 'Beach hopping, quick grocery runs, city alleys, surf breaks in Weligama & Mirissa'
  },
  {
    id: 'yamaha-rayzr',
    name: 'Yamaha RayZR 125cc',
    type: 'Lightweight Cruiser',
    ratePerDay: 18,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCAcMgXw28EwTS31Jbju1_wEQlTsI9h9f4gYqPBDJZftdlBHMjYDX9Qc-u1WHZXJ-8Xa2Io85Fb-yw9rWRn94WskCGkc7egXJBWtIumV_iC8Ix2R4w9Hde7Jk4u-FyzUSHbHnARjOvwM6lM4b945Y1FmU8YHGTOcqdIP37nVN8ThqNoTSAVaeO8vYnNEfiExWSsDzVhBLFJbvylvWR5YsW7oVSJN1B7_VfVH-rsCfADvHXafyCcS2hp',
    imageAlt: 'Yamaha RayZR 125cc modern sporty hybrid scooter parked on Galle coastal road with ocean views.',
    badge: 'Available',
    badgeType: 'available',
    engine: '125cc Fi Hybrid',
    deposit: '$50 or Passport',
    transmission: 'Automatic CVT',
    fuelCapacity: '5.2 Liters (Up to 55 km/L economy)',
    idealFor: 'Coastal highway cruises, couples riding with small backpacks, smooth handling'
  },
  {
    id: 'honda-pcx',
    name: 'Honda PCX 150cc',
    type: 'Comfort Maxi-Scooter',
    ratePerDay: 22,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAxvJTAhhgrcHil3WluuIDko794gElP3j0C_soRh895hvcJKVDRU0w09neZhYAuwuUm0uBCCs6KXVoZxgCFcJtdFbKQ2cv_xxR9eOKk0dhSlTu_o7-5n6W-r-rVS5p8hi2GdToKQVsHznspN7BPdYUKtTTfr75gBQoR5ub9zs2TRLa9THubeLI-gHYaxW6W-_dwY0q5VsgAABDHTwcsATw3d3wdhoUXKd8lrp5b_f07FsrzJCAh-N7G',
    imageAlt: 'Honda PCX 150cc luxury touring maxi scooter parked beside beach resort entrance in Mirissa Sri Lanka.',
    badge: 'Limited Fleet',
    badgeType: 'limited',
    engine: '150cc Liquid-Cooled',
    deposit: '$70 or Passport',
    transmission: 'V-Matic Automatic with Smart Key',
    fuelCapacity: '8.0 Liters (Comfort touring range ~350 km)',
    idealFor: 'Extended long-distance coastal touring, two riders with luggage, exceptional saddle comfort'
  },
  {
    id: 'yamaha-fzs',
    name: 'Yamaha FZ-S 150cc',
    type: 'Manual Road Bike',
    ratePerDay: 25,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDELoHZwa73MPSfv4tUC3SvoVAiDsSwnz7eN786bk4kJMvC1Xgaem5TaWnjTTZfTFbNjC7dCzvlOIw1pP6TCzrtHVihpkqokkbjddu74Bg_oOX1_QYHLUZP3BNs7N3hzNgB4YH4jbxZ44vQhfcZJwtwJLKbQqRK3QYhZtqlmisvOwTEd0nFfUc1arEZGPewYT6vB7JkfRgRGfti4qR1XGWQ5_dP78IDcLJIFtTIOkd0b7R3A72J2Avs',
    imageAlt: 'Yamaha FZ-S 150cc naked sport motorcycle parked on scenic windy tea country road in Ella Sri Lanka.',
    badge: 'Available',
    badgeType: 'available',
    engine: '150cc 5-Speed Manual',
    deposit: '$80 or Passport',
    transmission: '5-Speed Constant Mesh Manual',
    fuelCapacity: '13 Liters (Robust tank for hilly climbs)',
    idealFor: 'Highland hairpin bends, windy hill-country climbs around Ella and Nuwara Eliya'
  },
  {
    id: 'royal-enfield',
    name: 'Royal Enfield Classic 350',
    type: 'Classic Cruiser',
    ratePerDay: 35,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC-7rG7ZSK5q7aMBse4ktByKreRkc7OXMJB_72fQPOd4oT4wqTpi8ZOsUX3LrLpTEXHsXRurwUno_NySzM66lu6mmN6w96nr7ermaHg-_CwR64dgakiiz5bDKQOMIh55CSCjVIyyvk7mA9sIPJqDICwjVqfo5bT6VP9hGYSRPBhhTJWUR8X7reZQAAd9NmVRTNvqx45FFtlVZtIYdwBhs9YIjI-q_h_-JM7i-cw9C4c6GIdKHql-eID',
    imageAlt: 'Royal Enfield Classic 350 motorcycle parked in front of ancient colonial archway in Galle Fort Sri Lanka.',
    badge: 'Signature',
    badgeType: 'signature',
    engine: '350cc Single Cylinder J-Series',
    deposit: '$150 or Passport',
    transmission: '5-Speed Manual with Classic Thump',
    fuelCapacity: '13.0 Liters',
    idealFor: 'Iconic open road expeditions, photography journeys, unforgettable presence on Sri Lankan routes'
  }
];

export const DESTINATIONS: Destination[] = [
  {
    id: 'galle-fort',
    name: 'Galle Fort',
    category: 'Heritage & Coast',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDLZs7lMOiLGL-2pGh129PhnHXh9llryPyoJjrbS5CZgH0a_mXHkO5kTJWUAzKu-lcX2ZgK7itR_9Hin4zVw76v5zJDkcPUEzSnVg_LJDHYkC66J3DrhRL0l47qjzRoKzrLoBTPxH8bHdYPEHz32aerNGTVfrgum0lceFeTKRPhnGz7J7UVAAF5rr_tbXoZyhf4GzbVwR32AKOpqV_o2cO8Wbpqb80ZiVi8VunoJRK-qFVSNDFUBEUo',
    imageAlt: 'Dutch Fort Galle ancient stone sea ramparts with waves crashing in Sri Lanka during tropical golden hour.',
    description: 'Stroll cobblestone alleys, 17th-century ramparts, and boutique cafes along the ocean.',
    highlights: ['17th-century Dutch Fort', 'Iconic White Lighthouse', 'Galle Literary Cafes & Boutiques']
  },
  {
    id: 'hikkaduwa',
    name: 'Hikkaduwa',
    category: 'Beaches & Corals',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBBjsx28iVqrztuZVA3HFEyWvXzoPntbP2W-mlenf-e-Y1M1Y0a87TPrPa5yCvUarx8QzRG2i0L1pOZVRbCA9GuUZJyYTlIHE9xw9Ad7zKX7rM1X65p9OjeOo4na_lp6x3bQutpKmJF1Ts2Q9YvqWLqqNTIxJr6P-h77z3fxDpjckZxaQlpKsBPagAmr21opBZkf8GS97a7G3E-o_h2FFuabmji5rN-JUKKzi47dF1D-A9mVJ1hcM9H',
    imageAlt: 'Hikkaduwa shoreline with crystal blue waters, swaying palm trees and surfers enjoying waves in southern Sri Lanka.',
    description: 'Renowned for shallow coral reefs, sea turtle sanctuaries, surfing, and beachfront cafes.',
    highlights: ['Coral Reef Sanctuary', 'Wild Green Sea Turtles', 'Surfing & Nightlife']
  },
  {
    id: 'mirissa',
    name: 'Mirissa',
    category: 'Marine & Sunset',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCr9INVehMr-mvIkUgZTbNS7OnYsNrzMiH_WGseJ3l6l6GH99jpMgIujT-M2_NzJtxRZ-eUBxq-LmjkofCQWiD65kbaBIP18rfqe9_AtuDA_PkA60qzbZjxIJV40j1zvRgGqNweS9nduNzIuut4Xg1G6g4jkJ9Z8bGgWq_3lvwMYiQhMjrQOYYKMpj-gxdD9ggWWUjESmO5fd3tND-e0PXkB1WfPxyRqibL_-OIhnWlpT5Gk-7yaxEl',
    imageAlt: 'Mirissa bay curve with blue whale watching boats departing into deep blue ocean waters under morning sunlight.',
    description: 'World-famous blue whale watching, Coconut Tree Hill lookout, and vibrant beach night dining.',
    highlights: ['Blue Whale Watching', 'Coconut Tree Hill', 'Secret Beach Hideaway']
  },
  {
    id: 'unawatuna',
    name: 'Unawatuna',
    category: 'Calm Waters & Bays',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC3ak2X2s0ILRY8SSXtrD9tEHN2YakmyfGyEMbT72S9MKEbC0i0EIkV6uWiiZuw-n7A6GLlYzq8sgQ3ZN7Y-BUU_jzawOzWY6v4ULR_1ofPZXt-ZJ6fYhn4oQk0X4CkWiIspiITDve2u7NF9FGqaxtmAQMb7X-na-F0plDdFFVyioMky5ZCrkHlpQBypKbj7EXFP2Fqvc-CTrSHMkzRaf3AsCRpB2kR_nZ_ormUtAlXnSug7i4H8ttf',
    imageAlt: 'Unawatuna tranquil crescent bay with calm turquoise waters, golden sand and Japanese Peace Pagoda on the headland.',
    description: 'Sheltered crescent beach ideal for safe swimming, Jungle Beach hiking, and scuba diving.',
    highlights: ['Tranquil Safe Swimming Bay', 'Japanese Peace Pagoda', 'Jungle Beach Trail']
  },
  {
    id: 'ella',
    name: 'Ella',
    category: 'Mountain Trails',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDZFW6HsDJXPbjVSaWPKDZ73dPast5f8G_4YbsZMbAV8CHaHmr0s-Sj-S8AW0TGi41nm_uKkndPWZrTy-jlWtheS0Qsj3pwaK0ihhbrDOITC0RrpKusHnpCkclf-P0k_JR2-n974PF_avZrwBSnqHr7rCslDmP35LZa7V-ELLhZxemQ2f8mFDxcnH6vx4YMbEBbAInEyc6zBrDYTKR7sHHrQH-rywwai7Z5JdAgyU49gF1XQcj0PwDw',
    imageAlt: 'Highland mountain town of Ella with lush tea plantation valleys and Ella Rock peak bathed in gentle morning fog.',
    description: 'Misty gaps, iconic Nine Arch Bridge, Little Adam’s Peak trek, and cascading waterfalls.',
    highlights: ['Nine Arch Viaduct Bridge', 'Little Adam\'s Peak Trek', 'Ravana Falls & Cave']
  },
  {
    id: 'kandy',
    name: 'Kandy',
    category: 'Cultural Capital',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCPVq0bepIzxl_UALGrd643n9A6rQaGVgTzjWKda5gSGVhOuOS0wYgjKt5joSWDSI0gNQpvtFulVfXcYFFUIYbLMy3Vix6qgFidsdRdMkau1S3IRLXvjcwcvRcmutoR9gYr5BqSdrxv1LoFXm0psuWYHT07Mpgta837ovZKMO62W1_baM87FOdY6rfc2xPYm5ojwbKoflY3KADjNET5_wmMU1CYgM0bk4L3j8Cxf-NeoZ3s3SXBgnEe',
    imageAlt: 'Kandy sacred royal city with lake surrounded by forested hills and Temple of the Tooth.',
    description: 'Sri Lanka’s cultural heart with the Temple of the Sacred Tooth Relic and royal gardens.',
    highlights: ['Temple of the Tooth', 'Peradeniya Royal Gardens', 'Traditional Kandyan Dancers']
  },
  {
    id: 'sigiriya',
    name: 'Sigiriya',
    category: 'Ancient Wonder',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB_KnbILBKRC4XnwME9cz72tFrR5jfpgR4KEV1srcxVwmopLD0wWNwWq8w6LmSPXcUK6vW5W3QRBdjujlbgxheQMNQpEO7yCzWEDGL2MJVHqbgJnZ3dyQWs56bIDbyCq0dQD5R3fdyY02n-Pq6ZWnGSa0RbC4oMlRXFbBCAG2dY3OGJYWaps3yAK4etUpvpL0JLXe5YdToGhj5K38qHNrO2UvifQdbMysgJycB35GI0tHk9cQxBL8W3',
    imageAlt: 'Sigiriya ancient fortress rock surrounded by water gardens and jungle canopy in central Sri Lanka.',
    description: '5th-century mountain fortress with historical frescoes, water gardens, and Pidurangala Rock.',
    highlights: ['Sigiriya Lion Rock Citadel', 'Ancient Water Gardens', 'Pidurangala Sunrise Viewpoint']
  },
  {
    id: 'nuwara-eliya',
    name: 'Nuwara Eliya',
    category: 'Cool Tea Highlands',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDhgjjT36CcX9cdlvaem4VWGdbjVeGi1Q1webJru031D4zkJWav2LEmz7ml0Hpif6dgfXHl91zHpXZZ-YD4M0eC62vwKXeFMiB-8nicou_U2UP6Mu36FjXREiNa2PXNedn3Bu1Rzue4aZFXHEl1gBlxz53kHZDTnkRAuMjg_qGsOKoSIENGNUA4gPEWTWGZsl8VEDu5BAuMFqv-mjvkhXVFuVM0LwDnDgg6AXjYPeZORDWVGoyjNPUk',
    imageAlt: 'Tea plantations in Nuwara Eliya with female tea pickers in traditional attire working on rolling hills under cool misty skies.',
    description: '"Little England" hill station surrounded by pure Ceylon tea plantations, Gregory Lake, and cool breezes.',
    highlights: ['Pure Ceylon Tea Estates', 'Lake Gregory Boating', 'Colonial Post Office & Architecture']
  },
  {
    id: 'yala-national-park',
    name: 'Yala National Park',
    category: 'Wild Sanctuary',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAR_cECctG62alXiD3DcZoGyXxXNZ8TOF17JdKdr4hJ5SKWOmS9_RZz-oUuw1TwERFbWeFV8lsaAPv416NUk2zdUeIp7mjOVV_V_3JzdnDYTU1DFJ3NQhTgoXjsMCdHMhUkrHEbPRhrFMH0DIjPFSUt4AgaUHE6UBKugNr806o4hdrEkX6MsSmpmkIcsA0LaNTrz1w4K5SZty8JjXhbDQpKkqZS5wXcwEZVzfS4tEvBKjBAL-oiimBl',
    imageAlt: 'Herd of wild Asian elephants walking across grassy clearing in Yala National Park Sri Lanka near waterhole at dusk.',
    description: 'Premier wildlife reserve famed for high leopard density, elephants, crocodiles, and exotic birds.',
    highlights: ['Highest Leopard Density in Asia', 'Wild Elephant Herds', 'Coastal Wilderness & Lagoons']
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g1',
    title: 'Mirissa Sunset Shoreline',
    category: 'beaches',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDttGa7uvA6J0rdi4XOvdxouQ-ke1vpL-Pp_TPFcGNit1fW9dxxtCm_FRGn6J6QLTPfNBKHsduQ4ZQ7Tcm_BoCw4EGqaRCPHvuFYzQAX7J82YrUrBg-8cI8G691AqR7mg21sWIypYdSs-6HYcLeLz0pJZRO9C0HYtk94xJ8M3AOMnlUKfg2pq-3_mr0kBjACT6__WGEOMVV4wI_15xWw36UAT4wZvdhRcvWmXR2NBpcvydBnV9F13Fg',
    imageAlt: 'Golden sand beach in Mirissa Sri Lanka with curved palm trees over calm blue ocean water during serene golden hour.'
  },
  {
    id: 'g2',
    title: 'Nuwara Eliya Tea Pass',
    category: 'mountains',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCr2hFXXcFXXTrE8AuDvcWDtacz0PPQcmhcdwBcHim0heUPEEberbajPUlZu6LXx9OGEjhiZlSISCAaa38xBWGIVCJHyHwbMsFpk0OMMgdEKWRpUtzF27_DN4QjgxRw8gU4YD6M0bgFx26dTzWzKXbquLvirI52CxJCuSG6IGKrQdrQyKe1lhxnlfbCQrueHguMwgdVq6cMV8bYU0kxtZOIrsZbcxmB8TRd4JNCS69Fvcu6iaUCCM0R',
    imageAlt: 'Winding highland road in Sri Lanka surrounded by lush green tea hills and distant blue mountains shrouded in morning mist.'
  },
  {
    id: 'g3',
    title: 'Sigiriya Rock Fortress',
    category: 'heritage',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAYMRQxvfhCJK3XUJPw-ljhc0Y8riY3159AihApz6sit7AGO_e-8Kb3EZEdy_grGm5Njm84btWraqmIpGbuqydB9qdl2akecnDWi5BOi_uqpZ8umEcVjArdXZiqJHKQc7d3iu_uWgfZKJBBokwg6tFJjM5yArgF5UgJ4iCgn0TF21l7B8CVaYJ8QZI02-ZTbug2fvOgh3NVDHJBEAM1UEasrbFYUvsInG8UG9PZ4oxuirMqYJ85AWmn',
    imageAlt: 'Sigiriya Lion Rock fortress viewed across water lilies in ancient moat under clear sunny skies in Sri Lanka.'
  },
  {
    id: 'g4',
    title: 'Yala Wild Elephant Herd',
    category: 'wildlife',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAAHuy1lxDmkInhqKTzDt0nCvF4-38tL5WRVrThi6sXevugBYo7YNHUGhSR5abBd5oP6ra-Y085jAdJ9Se3DhyIvSJ7NVe-10G4PJhAtYzCFgFiKbAQiAk_XXSQPqKeEtvdNLE-fhmabWsMc3ZoP93G2p7i3aU2ZFnGLq8W1Cxenu-akeMal4jWXCkwhv0Xr6vg6fNaK_SL_HvU5u5HOaJ1u5CnXmrguw3uc0K-BPpv0D3VVpaba7Vu',
    imageAlt: 'Wild elephant mother and baby walking beside waterhole in Yala National Park Sri Lanka under soft afternoon sunshine.'
  },
  {
    id: 'g5',
    title: 'Coastal Scooter Cruise',
    category: 'bikes',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC9tF4afnOmKEblwI60T-Ryh3_elf68V_-gRpB712Qpesrpy1q2Jndoei-VwNDTeOAq7dIkVuZ26_sJO79K7FbtEPpDxQEM0UOyhRuywpqcwUrZ1dpiFrss7k9uciJX6U_P8L9tOMhBHQ_kvrjcQWxkk7EPqlstovOelrrlzSwJLpZmGkGK72pLGDDZs1BVvOyTShABkbuIo8nyojtMX4rQmg0K2h5lSWw5pCujfv20wyMNUX347Gn1',
    imageAlt: 'Two rental scooters parked by a scenic coastal lookout in Weligama Bay overlooking surfers in the ocean.'
  },
  {
    id: 'g6',
    title: 'Unawatuna Bay',
    category: 'beaches',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD1riffeKNss5NAHReYpXTBmYh-mNJ08jS0XBnb7RdKi-5tkLNIo58_7Uboj0qh-vypSavLzCp8HbnNYS1rpu-l5lYxKX_3e02rWT4eftPxa7Q_l2NhDDY7G_kz0oAMey7fHRt36FMmD4RGug8Ac7yTRImtf1ONm2kJIjCb7u1-Q503SMBw1cR-8RiCPoOpScH2r4gvUhY26MDIbNPZjVCjOJ-KVriu1c7OMWJ-c9RSUZ6UgO_xAnJy',
    imageAlt: 'Unawatuna beach with clear turquoise ocean, small wooden fishing boat on shore and lush tropical greenery.'
  },
  {
    id: 'g7',
    title: 'Royal Enfield in Ella',
    category: 'bikes',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBuTnOXSXXkpc0phXX4MB3vf3N2rm69olNeRadS95KLjzl_j6LPfL_FmEOu18l-BG4pFQpMQHv3g3Nk0BZ1Qn8Z4tVZBMki0QW0Tf62Q-Qwle9xwYLgZcUcH2hDnjaiJMjmacLujB7W71r3YbY86yQGBugScgRI75mDdeSXqDsRCT7QIGpUbQdKCnTMYf-1igZJ3cfJAoEcMWKFS1ayp1X20kcwlJp_005uqBVOW1wgBCtSWYcJJTkL',
    imageAlt: 'Royal Enfield Classic motorcycle parked next to high mountain tea garden in Ella with scenic valley below.'
  },
  {
    id: 'g8',
    title: 'Dambulla Cave Shrines',
    category: 'heritage',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDBM7vo2bQQg1-YNgdk0OvMkc5PNVbAtAQ4k3spCUeCZ8UnAHJQtTwzCS25U92wb9WzySVEphCGPYbea-PvX_4ks9m4c-dAQTcJeW3ZrAQNt7PLUSdh2RCJMnfp2uAqgWQ9jwQFbLbUUOJ8JjrhRoAhnrHHLWy0i1_w6bBa57nTALE2BIPbkPQu_M5yYngONx2pmrtafEuD6tiAoeb04tRZWk_CbBCrdRZ6Ttk9PZBGtxZmwJ6U2dgd',
    imageAlt: 'Ancient Dambulla Cave Temple Buddha statues carved into stone with golden lanterns and oil lamps glowing warmly.'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    quote: 'Rented two Yamaha RayZR scooters for 8 days exploring Weligama, Mirissa, and Galle. The bikes were in pristine mechanical condition, and helmet quality was top-notch.',
    author: 'Liam & Sophie',
    country: 'United Kingdom',
    flag: '🇬🇧',
    tourType: 'Scooter Rental',
    rating: 5
  },
  {
    id: 't2',
    quote: 'Our driver was calm, punctual, and knew all the scenic detours through Nuwara Eliya and Ella. Having our own private van made traveling with two children completely stress-free.',
    author: 'Markus Weber',
    country: 'Germany',
    flag: '🇩🇪',
    tourType: 'Private Van Tour',
    rating: 5
  },
  {
    id: 't3',
    quote: 'Booked the Royal Enfield Classic 350 for the southern coastal highway loop. Seamless WhatsApp communication and quick passport check at pickup. Unforgettable week.',
    author: 'Camilla Rossi',
    country: 'Italy',
    flag: '🇮🇹',
    tourType: 'Royal Enfield Experience',
    rating: 5
  },
  {
    id: 't4',
    quote: 'The airport transfer from Colombo BIA to Galle was waiting with a cold towel and water right as our flight landed at midnight. Truly 5-star island concierge service.',
    author: 'David & Claire Miller',
    country: 'Australia',
    flag: '🇦🇺',
    tourType: 'Airport Transfer & Safari',
    rating: 5
  }
];

export const SERVICES_LIST = [
  {
    icon: 'map',
    title: 'Sri Lanka Tour Packages',
    desc: 'Full multi-day structured itineraries covering key highlights from the coast to the central tea hills.',
    actionLabel: 'View packages',
    target: '#packages',
    category: 'Sri Lanka Tour Package'
  },
  {
    icon: 'edit_road',
    title: 'Customized Private Tours',
    desc: 'Personalized itineraries created around your preferred travel pace, dates, and interests.',
    actionLabel: 'Build custom trip',
    target: '#booking',
    category: 'Customized Private Tour'
  },
  {
    icon: 'flight_land',
    title: 'Airport Transfers',
    desc: 'Punctual pickup and drop-off transfers to and from Colombo BIA (Katunayake) and Mattala Airport.',
    actionLabel: 'Book transfer',
    target: '#booking',
    category: 'Airport Transfer (BIA / Mattala)'
  },
  {
    icon: 'airport_shuttle',
    title: 'Car & Van Hire + Driver',
    desc: 'Comfortable, air-conditioned fleet options with professional English-speaking drivers for island transit.',
    actionLabel: 'Inquire vehicle',
    target: '#booking',
    category: 'Private Car/Van with Driver'
  },
  {
    icon: 'temple_buddhist',
    title: 'Cultural & Heritage Tours',
    desc: 'Explore UNESCO world heritage sites like Sigiriya Rock, Kandy Temple of the Tooth, and ancient capitals.',
    actionLabel: 'See heritage tours',
    target: '#packages',
    category: 'Sri Lanka Tour Package'
  },
  {
    icon: 'surfing',
    title: 'Beach & Coastal Tours',
    desc: 'Relax along the southern and eastern shorelines from Hikkaduwa and Mirissa to Nilaveli and Arugam Bay.',
    actionLabel: 'Explore coastal routes',
    target: '#packages',
    category: 'Customized Private Tour'
  },
  {
    icon: 'forest',
    title: 'Nature & Wildlife Tours',
    desc: 'Jeep safaris into Yala, Udawalawe, and Minneriya to witness wild elephants, leopards, and bird sanctuaries.',
    actionLabel: 'Safari packages',
    target: '#packages',
    category: 'Sri Lanka Tour Package'
  },
  {
    icon: 'two_wheeler',
    title: 'Bike & Scooter Rental',
    desc: 'Freedom on two wheels. Well-maintained scooters and road bikes available with flexible daily or weekly rates.',
    actionLabel: 'Explore bikes & rates',
    target: '#bikerental',
    category: 'Bike & Scooter Rental',
    popular: true
  }
];

export const WHY_US_CARDS = [
  {
    icon: 'favorite',
    color: 'secondary',
    title: 'Personalized Experiences',
    desc: "We don't do rigid assembly-line tours. Every plan is tailored to whether you prefer leisurely breakfasts or early sunrise surf sessions."
  },
  {
    icon: 'handshake',
    color: 'tertiary',
    title: 'Friendly Local Assistance',
    desc: 'Born and raised on the island, our team knows road conditions, uncrowded viewpoints, and genuine family-run eateries.'
  },
  {
    icon: 'calendar_month',
    color: 'secondary',
    title: 'Flexible Itineraries',
    desc: 'Want an extra hour watching the sunset at Mirissa? Need to postpone a hill hike due to rain? We adapt seamlessly to your flow.'
  },
  {
    icon: 'directions_car',
    color: 'tertiary',
    title: 'Convenient Transportation',
    desc: 'Choose exactly how you move: private chauffeur-driven AC vehicles for relaxed touring or scooters and motorbikes for open-air freedom.'
  },
  {
    icon: 'speed',
    color: 'secondary',
    title: 'Easy Tour & Rental Inquiries',
    desc: 'No complicated signup forms or hidden charges. Instant quoting via WhatsApp with direct confirmation from our local desk.'
  },
  {
    icon: 'headset_mic',
    color: 'tertiary',
    title: 'Dedicated On-Road Support',
    desc: 'From the moment you pick up your bike or step off the airplane at BIA, our concierge desk is only a quick WhatsApp message away.'
  }
];
