---
name: Ceylon Horizon
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#44474d'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#74777d'
  outline-variant: '#c4c6cd'
  surface-tint: '#4d6079'
  primary: '#000917'
  on-primary: '#ffffff'
  primary-container: '#0d2137'
  on-primary-container: '#7689a4'
  inverse-primary: '#b5c8e5'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#100600'
  on-tertiary: '#ffffff'
  tertiary-container: '#301b00'
  on-tertiary-container: '#bd7800'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d2e4ff'
  primary-fixed-dim: '#b5c8e5'
  on-primary-fixed: '#081c32'
  on-primary-fixed-variant: '#364860'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-hero:
    fontFamily: Outfit
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
  display-hero-mobile:
    fontFamily: Outfit
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg:
    fontFamily: Outfit
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md-mobile:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Outfit
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers an elevated, modern-tropical aesthetic tailored for high-end island exploration, curated motorcycle expeditions, and luxury tours across Sri Lanka. It pairs the disciplined tranquility of high-end hospitality with the kinetic spirit of open-road travel.

### Design Movement & Aesthetic
The visual language merges **Refined Modern Hospitality** with **Ambient Tropical Minimalism**. It relies on expansive negative space, deep oceanic and night-sky tones, verdant emerald counterweights, and sun-drenched golden accents. The mood avoids generic backpacker tropes in favor of editorial prestige: crisp card compositions, cinematic imagery treatments, subtle glass-tinted overlays, and effortless spatial transitions.

### Emotional Response
- **Serenity & Trust:** Grounded by deep navy surfaces, precise geometry, and immaculate typography.
- **Wanderlust & Vibrancy:** Sparked by emerald flora notes and sun-kissed amber cues representing golden hours along the southern coast and central highlands.
- **Freedom & Control:** Engineered for seamless fleet booking, route curation, and effortless itinerary planning with zero visual clutter.

## Colors

The palette draws directly from the contrasts of Sri Lanka: deep oceanic shelf blues, lush tea-estate emeralds, luminous coastal sunlight, and chalk-white architectural planes.

### Palette Architecture
- **Primary (`#0D2137` / `#0A192F`):** Deep Navy Blue. Used for foundational navigation, primary CTAs, authoritative editorial headlines, and luxury contrast blocks.
- **Secondary (`#10B981` / `#0F9D58`):** Tropical Emerald Green. Represents vitality, eco-routes, bike availability states, success prompts, and nature-forward accents.
- **Tertiary (`#F59E0B` / `#FBBF24`):** Warm Amber & Golden Yellow. Reserved for rating stars, key highlight badges, sunrise tour tags, and attention-critical alerts.
- **Neutral Surface System (`#FFFFFF` to `#F8FAFC`):** Crisp pure white provides the canvas baseline, supported by pale cool-tinted sands (`#F1F5F9`) for secondary card groupings and subtle structural division.
- **Text & Foreground Hierarchy:**
  - High-emphasis text: Deep Navy `#0A192F`
  - Medium-emphasis text: Slate Blue `#475569`
  - Disabled / Outline text: Muted Sky Slate `#94A3B8`

### Color Distribution Principle
Apply the **60-30-10 Rule**: 60% airy neutral white and soft coastal off-white space, 30% structured navy foundations and card headers, and 10% curated emerald and amber sparks for micro-interactions, availability indicators, and booking conversions.

## Typography

Typography balances architectural elegance with warm, approachable clarity.

- **Headlines (Outfit):** Modern geometric shapes with sculpted terminals provide distinctive character for luxury itineraries, vehicle classifications (e.g., Royal Enfield Scram 411, BMW GS), and geographical milestones.
- **Body & Controls (Plus Jakarta Sans):** Highly legible, humanistic, and fluid. The generous x-height ensures technical specifications (engine displacement, deposit terms, terrain ratings) remain effortless to read across all viewport sizes.
- **Letter Spacing:** Apply `-0.02em` for headlines above 32px to create tight, magazine-like authority. Apply `+0.04em` tracking to uppercase mini-labels (`label-sm`) for category chips and status badges.

## Layout & Spacing

The layout is constructed around an intentional 12-column responsive fluid grid with generous page boundaries to reflect coastal openness.

### Breakpoints & Layout Rules
- **Desktop (≥ 1280px):** 12-column grid, max-width `1360px`, `3rem` (48px) margins, and `1.5rem` (24px) gutters. Rich horizontal split views for itinerary details and bike specifications.
- **Tablet (768px – 1279px):** 8-column grid, dynamic margins `2rem` (32px), `1.25rem` (20px) gutters. 2-column card structures for fleet catalogues.
- **Mobile (< 768px):** 4-column grid, `1.25rem` (20px) outer edge margins, `1rem` (16px) gutters. Cards stack vertically or shift into smooth edge-peeking horizontal snap carousels for tour packages.

### Spacing Rhythm
Adopt an 8px spatial grid. Component interior paddings use `space-md` (16px) for compact widgets and `space-lg` (24px) for prominent rental reservation modules. Vertical section cadences leverage expanded `space-xl` intervals to prevent cognitive fatigue.

## Elevation & Depth

Visual depth is achieved through layered daylight physics rather than heavy structural borders. Ambient oceanic-tinted shadows evoke clean Sri Lankan sunshine bouncing off whitewashed coastal architecture.

### Elevation Levels
- **Level 0 (Flat Ground):** `#FFFFFF` surfaces sitting directly on the canvas or `#F8FAFC` backdrop bands with no shadow.
- **Level 1 (Subtle Lift - Resting Cards & Panels):** Subtle tinted ambient shadow: `0 4px 20px -2px rgba(10, 25, 47, 0.05), 0 2px 6px -1px rgba(10, 25, 47, 0.03)`. Edge definition using a 1px inner border tint of `rgba(13, 33, 55, 0.06)`.
- **Level 2 (Hover State & Floating Dropdowns):** Lifted shadow with a slight green/navy warmth: `0 12px 32px -4px rgba(10, 25, 47, 0.08), 0 4px 12px -2px rgba(10, 25, 47, 0.04)`.
- **Level 3 (Modals, Booking Sheets & Overlays):** Deep ambient diffusion: `0 24px 48px -12px rgba(10, 25, 47, 0.16), 0 12px 24px -4px rgba(10, 25, 47, 0.08)`.

### Glass & Frosted Overlays
For sticky navigation headers and floating bike rental quick-filters over photography, use a backdrop blur of `blur(16px)` with `rgba(255, 255, 255, 0.82)` and a hairline bottom divider of `rgba(13, 33, 55, 0.08)`. Dark-mode contextual image pill badges use `rgba(10, 25, 47, 0.65)` with backdrop blur.

## Shapes

The design system embraces a **Rounded (Level 2)** geometry: soft, inviting, and premium, avoiding both sterile hard edges and informal cartoonish pills.

### Geometry Specifications
- **Standard Cards, Panels & Modals:** `1rem` (16px / `rounded-lg`) corner radii for structured balance.
- **Buttons, Form Inputs & Select Pickers:** `0.5rem` (8px / base roundedness) for precise, purposeful action points.
- **Hero Banners & Feature Highlights:** `1.5rem` (24px / `rounded-xl`) to frame landscapes and machinery gracefully.
- **Micro Chips, Route Badges & Status Tags:** Fully rounded pill curves (`9999px`) to visually separate operational metadata from structural containers.

## Components

### Buttons
- **Primary Action (Book Now / Reserve Bike):** Solid Deep Navy (`#0D2137`) background, Crisp White text, Outfit font weight 600, 8px radius. Hover transition: transforms into a rich dark shade (`#0A192F`) with a 2px vertical lift and subtle ambient shadow.
- **Secondary Action (Explore Itinerary):** Emerald Green (`#10B981`) background, Crisp White text. Used for conversion moments with immediate positive connotations.
- **Ghost / Outlined:** Transparent surface, 1.5px border of `#0D2137` (or White over photography), navy text. On hover: soft wash of `rgba(13, 33, 55, 0.04)`.
- **Accent Interactive (Instant Inquire):** Amber accent (`#F59E0B`) with deep navy text for high-priority flash offers or seasonal expedition bookings.

### Cards (Bikes & Tours)
- **Fleet Card:** Pure white background, `rounded-lg` (16px), Level 1 shadow, 1px border `rgba(13, 33, 55, 0.06)`. High-res asset thumbnail positioned at the top with an integrated specs badge (CC, Transmission, Luggage Capacity) rendered in subtle glassmorphism. Bottom footer displays daily rate in Navy, availability badge in Emerald, and quick-reserve trigger.
- **Tour Expedition Card:** Full-bleed image header with subtle bottom gradient, overlayed with warm amber rating pills and duration tokens (e.g., "7 Days / Southern Coast & Hill Country").

### Chips & Badges
- **Status Indicators:**
  - Available: Pale emerald background (`#ECFDF5`), bold emerald text (`#065F46`).
  - Limited Fleet: Soft amber background (`#FFFBEB`), bold amber text (`#92400E`).
- **Feature Filter Chips:** Crisp white background with `0.5rem` radius, light border (`#E2E8F0`). Selected state shifts to `#0D2137` fill with white text.

### Form Inputs & Date/Route Pickers
- **Input Fields:** Crisp White interior, 48px height, 8px radius, border `1.5px solid #E2E8F0`. Focus state shifts to Primary Navy outline (`#0D2137`) with an outer focus-ring in soft emerald glow (`rgba(16, 185, 129, 0.2)`).
- **Date & Location Selector Bar:** Floating unified horizontal card resembling a luxury concierge dock, segmenting "Pick-up Location", "Drop-off Location", "Dates", and "Motorcycle Class" with delicate vertical rules.

### Checkboxes & Radios
- **Checkboxes:** 20px box, 4px border radius. Unchecked: 1.5px slate border (`#CBD5E1`). Checked: Solid `#10B981` (Emerald) with white checkmark icon.
- **Radio Buttons:** Concentric circles. Selected state features a vibrant emerald dot encircled by navy focus halos.

### Specialized Component: Expedition Spec Matrix
A dedicated horizontal specification strip designed for bike models: engine power, seat height, fuel range, and luggage capacity displayed in 4 balanced mini-quadrants featuring muted slate micro-labels (`label-sm`) and bold navy values (`title-md`).